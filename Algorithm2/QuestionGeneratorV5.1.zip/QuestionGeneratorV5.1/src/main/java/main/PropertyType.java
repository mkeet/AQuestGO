/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author toky.raboanary
 */
public enum PropertyType {
    
    //OP_HAS,
    OP_HAS_NOUNS,
    OP_IS_NOUNS_PREP,
    
    //OP_VERB_PREP_NOUNS,
    OP_IS_PAST_PARTICIPLE_BY, 
    OP_IS_PAST_PARTICIPLE_PREP,
    OP_VERB, 
    OP_VERB_PREP,
    OP_UNKNOWN
}
