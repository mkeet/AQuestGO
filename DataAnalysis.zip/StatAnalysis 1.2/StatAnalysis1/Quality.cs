﻿using System;
namespace StatAnalysis1
{
    public enum Quality
    {
        VERY_GOOD,
        GOOD,
        AVERAGE,
        BAD,
        VERY_BAD,
        UNKNOWN
    }
}
