﻿using System;
namespace StatAnalysis1
{
    public enum OntologyName
    {
        AWO,
        STUFF,
        BIOTOP,
    }
}
