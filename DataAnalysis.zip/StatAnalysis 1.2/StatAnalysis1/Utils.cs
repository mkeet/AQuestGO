﻿using System;
using System.Collections.Generic;

namespace StatAnalysis1
{
    public static class Utils
    {
        public static Quality[] Qualities = { Quality.VERY_GOOD, Quality.GOOD, Quality.AVERAGE, Quality.BAD, Quality.VERY_BAD };
        public static bool IsNumber(String s)
        {
            if (s == "0" || s == "1" || s == "2" || s == "3" || s == "4" || s == "5" || s == "6" || s == "7" || s == "8" || s == "9")
                return true;
            return false;
        }
        public static double EchelleLikert(Quality quality)
        {
            switch (quality)
            {
                case Quality.VERY_GOOD:
                    return 5;
                case Quality.GOOD:
                    return 4;
                case Quality.AVERAGE:
                    return 3;
                case Quality.BAD:
                    return 2;
                case Quality.VERY_BAD:
                    return 1;
                default:
                    return 10000;
            }
        }
        public static String GetQualityStr(Quality quality)
        {
            switch (quality)
            {
                case Quality.VERY_GOOD:
                    return "Very Good";
                case Quality.GOOD:
                    return "Good";
                case Quality.AVERAGE:
                    return "Average";
                case Quality.BAD:
                    return "Bad";
                case Quality.VERY_BAD:
                    return "Very Bad";
                default:
                    return "Unknown";
            }
        }
        public static Quality EchelleLikertToQuality(int echelleLikert)
        {
            switch (echelleLikert)
            {
                case 5:
                    return Quality.VERY_GOOD;
                case 4:
                    return Quality.GOOD;
                case 3:
                    return Quality.AVERAGE;
                case 2:
                    return Quality.BAD;
                case 1:
                    return Quality.VERY_BAD;
                default:
                    return Quality.UNKNOWN;
            }
        }

        public static Quality GetQuality(String value)
        {
            value = value.ToUpper().Trim();
            Quality quality;
            switch (value)
            {
                case "A":
                    quality = Quality.VERY_GOOD;
                    break;
                case "B":
                    quality = Quality.GOOD;
                    break;
                case "C":
                    quality = Quality.AVERAGE;
                    break;
                case "D":
                    quality = Quality.BAD;
                    break;
                case "E":
                    quality = Quality.VERY_BAD;
                    break;
                default:
                    quality = Quality.UNKNOWN;
                    break;
            }
            return quality;
        }
        public static int GetMedian(List<int> list)
        {
            list.Sort();
            int mid = 0;
            if(list.Count % 2 == 0)
            {
                mid = list.Count / 2;
            }
            else
            {
                mid = list.Count / 2;

            }
            //Console.WriteLine("indice "+ mid+" - number of elements = "+list.Count);
            return list[mid];
        }

        public static String QualitiesToStr(List<Quality> qualities)
        {
            string str = "";
            foreach (var quality in qualities)
            {
                str += quality + "-";
            }
            str = str.Substring(0, str.Length - 1);
            return str;
        }
    }
}
