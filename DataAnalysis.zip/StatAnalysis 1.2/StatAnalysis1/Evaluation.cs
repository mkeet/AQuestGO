﻿using System;
namespace StatAnalysis1
{
    public class Evaluation
    {
        public Quality Syntax { get; set; }
        public Quality Semantics { get; set; }
        public Evaluation()
        {
        }
        public Evaluation(Quality syntax, Quality semantics)
        {
            this.Syntax = syntax;
            this.Semantics = semantics;
        }

        public Evaluation (String syntax, String semantics)
        {
            this.SetQualitySyntaxStr(syntax);
            this.SetQualitySemanticsStr(semantics);
        }

        public void SetQualitySyntaxStr(String str)
        {
            this.Syntax = Utils.GetQuality(str);
        }

        public void SetQualitySemanticsStr(String str)
        {
            this.Semantics = Utils.GetQuality(str);
        }

        
    }
}
