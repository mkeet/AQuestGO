﻿using System;
using System.Collections.Generic;

namespace StatAnalysis1
{
    public class Elements:List<Element>
    {
        public Elements()
        {
        }
        public List<String> GetHistoLatex()
        {
            List<String> lines = new List<string>();
            String histoHead = "symbolic x coords= {";
            String histoContent = "\\addplot coordinates {";

            foreach (var element in this)
            {
                String sampleName = element.Label;
                histoHead += sampleName + ",";
                String coordinate = "(" + sampleName + "," + element.GetValueStr() + ") ";
                histoContent += coordinate;
            }
            histoHead = histoHead.Substring(0, histoHead.Length - 1) + "},";
            histoContent += "};";
            lines.Add(histoHead);
            lines.Add(histoContent);
            return lines;
        }

        public List<String> GetPieLatex()
        {
            List<String> lines = new List<string>();
            lines.Add("\\begin{tikzpicture}");
            lines.Add("\\pie[rotate = 240,");
            lines.Add("text = pin,");
            lines.Add("explode = 0.2,");
            lines.Add("color ={ green!100,green!50,yellow!20,red!50, red!50}]");
            lines.Add("{");
            int indice = 0;

            foreach (var elt in this)
            {
                if (indice<this.Count-1) 
                    lines.Add(elt.GetValueStr() + "/" + elt.Label+",");
                else lines.Add(elt.GetValueStr() + "/" + elt.Label);
                indice++;
            }

            lines.Add("\\end{tikzpicture}");
            return lines;

        }
        /*public List<String> GetReportInstanceConfidenceSyntax()
        {
            List<String> report = new List<string>();
            report.Add("Report on Confidentiality of Syntax : ");
            String histoHead = "symbolic x coords= {";
            String histoContent = "\addplot coordinates {";
            int indice = 1;
            foreach (var instance in this.Instances)
            {
                String sampleName = "Sample" + indice;
                histoHead += sampleName + ",";
                double ecartMeanSyntax = this.GetEcartMeanSyntaxForInstance(instance);
                report.Add("Instance numero " + instance.Index + " (" + instance.Name + ") : inconfidence = " + ecartMeanSyntax);
                String value = String.Format("{0:0.00}", ecartMeanSyntax);
                String coordinate = "(" + sampleName + "," + value + ") ";
                histoContent += coordinate;
                indice++;
            }
            histoHead = histoHead.Substring(0, histoHead.Length - 1) + "},";
            histoContent += "};";
            return report;
        }*/
    }
}
