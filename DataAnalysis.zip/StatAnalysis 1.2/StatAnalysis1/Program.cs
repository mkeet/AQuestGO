﻿using System;
using System.Collections.Generic;
using System.IO;

namespace StatAnalysis1
{
    class Program
    {
        static void Main(string[] args)
        {
            String directoryPath = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV";
            String filenameSyntaxReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/Questions_syntax.csv";
            String filenameSemanticsReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/Questions_semantics.csv";
            String filenameGeneralReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/GeneralReport.csv";
            //String filenameConfidenceReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/ConfidenceReport.csv";

            // Report Mean for each Ontology
            String filenameAWOReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/AWOReport.csv";
            String filenameStuffReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/StuffReport.csv";
            String filenameBioTopReport = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/BioTopReport.csv";

            // Report Mean for each Ontology (Recap)
            String filenameAWOReportRecap = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/AWOReportRecap.csv";
            String filenameStuffReportRecap = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/StuffReportRecap.csv";
            String filenameBioTopReportRecap = "/Users/toky.raboanary/ Research/PhD UCT/Questions generation/ExperimentCSV/Report/BioTopReportRecap.csv";

            String filenameReportRecap = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/GeneralReportRecap.csv";

            String filenameAgreementAll = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/AgreementAll.csv";
            String filenameAgreementAWO = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/AgreementAWO.csv";
            String filenameAgreementStuff = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/AgreementStuff.csv";
            String filenameAgreementBiotop = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/AgreementBiotop.csv";


            String filenameMedianWithDetailSyn = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/MedianDetailAllSyn.csv";
            String filenameMedianWithDetailSem = "/Users/toky.raboanary/Research/PhD UCT/Questions generation/ExperimentCSV/Report/MedianDetailAllSem.csv";

            Experiment experiment = new Experiment(directoryPath);

            Console.Clear();

            // Inter-rater agreement BEGIN
            List<String> agreementAll = experiment.CheckAgreementSyntax(null);
            agreementAll.Add(""); agreementAll.Add("");
            agreementAll.AddRange(experiment.CheckAgreementSemantics(null));
            File.WriteAllLines(filenameAgreementAll, agreementAll);

            List<String> agreementAWO = experiment.CheckAgreementSyntax(OntologyName.AWO);
            agreementAWO.Add(""); agreementAWO.Add("");
            agreementAWO.AddRange(experiment.CheckAgreementSemantics(OntologyName.AWO));
            File.WriteAllLines(filenameAgreementAWO, agreementAWO);

            List<String> agreementStuff = experiment.CheckAgreementSyntax(OntologyName.STUFF);
            agreementStuff.Add(""); agreementStuff.Add("");
            agreementStuff.AddRange(experiment.CheckAgreementSemantics(OntologyName.STUFF));
            File.WriteAllLines(filenameAgreementStuff, agreementStuff);

            List<String> agreementBiotop = experiment.CheckAgreementSyntax(OntologyName.BIOTOP);
            agreementBiotop.Add(""); agreementBiotop.Add("");
            agreementBiotop.AddRange(experiment.CheckAgreementSemantics(OntologyName.BIOTOP));
            File.WriteAllLines(filenameAgreementBiotop, agreementBiotop);

            // Inter-rater agreement END

           

            experiment.PrintReport();
            //experiment.PrintReportCondifence();

            experiment.SaveReportQuestionsSyntax(filenameSyntaxReport);
            experiment.SaveReportQuestionsSemantics(filenameSemanticsReport);
            experiment.SaveGeneralReport(filenameGeneralReport);
            //experiment.Sa
            //experiment.SaveReportConfidence(filenameConfidenceReport);
            //experiment.PrintReportQuestions();

            // Report Mean for each Ontology
            experiment.SaveReportQuestionsWithMean(filenameAWOReport, OntologyName.AWO);
            experiment.SaveReportQuestionsWithMean(filenameStuffReport, OntologyName.STUFF);
            experiment.SaveReportQuestionsWithMean(filenameBioTopReport, OntologyName.BIOTOP);

            // Report Mean for each Ontology (Recap)
            experiment.SaveReportRecapMeanOntology(filenameAWOReportRecap, OntologyName.AWO);
            experiment.SaveReportRecapMeanOntology(filenameStuffReportRecap, OntologyName.STUFF);
            experiment.SaveReportRecapMeanOntology(filenameBioTopReportRecap, OntologyName.BIOTOP);

            experiment.SaveReportRecapMean(filenameReportRecap);


            // experiment Detail Median

            List<String> linesSyn = experiment.GetMedianAllOntologiesSyn();
            File.WriteAllLines(filenameMedianWithDetailSyn, linesSyn);
            List<String> linesSem = experiment.GetMedianAllOntologiesSem();
            File.WriteAllLines(filenameMedianWithDetailSem, linesSem);


            // Generating Fleiss Kappa coefficient using R language
            experiment.PrintTableForR("Syn", TypeEvaluation.SYNTAX); //R Language generator

            // Generating Fleiss Kappa coefficient using R language
            experiment.PrintTableForR("Sem", TypeEvaluation.SEMANTICS); //R Language generator
            Console.ReadLine();

        }
    }
}
