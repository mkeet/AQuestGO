﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace StatAnalysis1
{
    public class Experiment
    {
        public String Path { get; set; }
        public List<Question> Questions { get; set; }
        List<Instance> Instances { get; set; }

        public Experiment(String path)
        {
            this.Path = path;
            DirectoryInfo d = new DirectoryInfo(this.Path);//Assuming Test is your Folder
            this.Questions = new List<Question>();
            this.Instances = new List<Instance>();
            FileInfo[] filenames = d.GetFiles();

            int indexInstance = 0;
            foreach (var filename in filenames)
            {
                Console.WriteLine(filename);
                Console.WriteLine();
                String[] lines = File.ReadAllLines(filename.FullName);

                if (!filename.FullName.Contains(".csv"))
                    continue;

                Instance instance = new Instance(filename.FullName, indexInstance);
                instance.Experiment = this;
                this.Instances.Add(instance);
                for (int i = 19; i < lines.Length; i++)
                {
                    String line = lines[i];
                    if (line.Length == 0) continue;
                    String firstChar = line.Substring(0, 1);
                    if (Utils.IsNumber(firstChar))
                    {
                        Question existingQuestion = this.GetQuestion(i);
                        if (existingQuestion == null)
                        {
                            Question q = new Question(i, line);
                            this.Questions.Add(q);
                            existingQuestion = q;
                        }
                        else
                        {
                            existingQuestion.AddNewQualities(line);
                        }
                    }
                }
                indexInstance++;
            }
        }


        public int GetCountSyntax(Quality quality)
        {
            int count = 0;
            foreach (var question in this.Questions/*.Where(x=>x.OntologyName == OntologyName.STUFF)*/)
            {
                count += question.GetCountSyntaxQuality(quality);
            }
            return count;
        }
        public int GetCountSemantics(Quality quality)
        {
            int count = 0;
            foreach (var question in this.Questions/*.Where(x => x.OntologyName == OntologyName.STUFF)*/)
            {
                count += question.GetCountSemanticsQuality(quality);
            }
            return count;
        }


        public List<String> GetMedianAllOntologiesSyn()
        {
            List<String> lines = new List<string>();

            foreach (var question in this.Questions)
            {
                List<Quality> winQual;
                int number;
                question.GetMostVotedQualityNumberSynTab(out winQual, out number);
                String line = question.QuetisonStr + "," + question.GetOrderedEvaluationsCSV(TypeEvaluation.SYNTAX) +number+","+Utils.QualitiesToStr(winQual);
                lines.Add(line);
            }
            return lines;
        }

        public List<String> GetMedianAllOntologiesSem()
        {
            List<String> lines = new List<string>();

            foreach (var question in this.Questions)
            {
                List<Quality> winQual;
                int number;
                question.GetMostVotedQualityNumberSemTab(out winQual, out number);
                String line = question.QuetisonStr + "," + question.GetOrderedEvaluationsCSV(TypeEvaluation.SEMANTICS) +number+","+Utils.QualitiesToStr(winQual);
                lines.Add(line);
            }
            return lines;
        }

        public List<String> CheckAgreementSemantics(OntologyName? ontologyName)
        {
            List<String> agreements = new List<string>();

            List<int> numbers = new List<int>();
            List<Question> quest;
            if (ontologyName == null)
            {
                String titleAll = "Inter-rater Agreeement from AWO & STUFF & BIOTOP Ontology - Semantics";
                Console.WriteLine(titleAll);
                agreements.Add(titleAll);
                quest = this.Questions;
            }
            else
            {
                String titleOnt = "Inter-rater Agreeement from "+ontologyName.ToString()+" - Semantics";
                Console.WriteLine(titleOnt);
                agreements.Add(titleOnt);
                quest = this.Questions.Where(x => x.OntologyName == ontologyName).ToList();
            }
            
            String header = "Question;";
            int i = 1;
            foreach (var ev in this.Questions.FirstOrDefault().Evaluations)
            {
                header += "Evaluator" + i + ";";
                i++;
            }
            header += "Result;Frequency;";
            agreements.Add(header);
            foreach (var question in quest)
            {
                Quality winQual;
                int number;
                question.GetMostVotedQualityNumberSem(out winQual, out number);
                String line = question.QuetisonStr + ";"+ question.GetEvaluationsCSV(TypeEvaluation.SEMANTICS)+ winQual.ToString().ToUpper() + ";" + number;
                numbers.Add(number);
                agreements.Add(line);
                Console.WriteLine(line);
            }

            var numberOfAgreement6 = numbers.Where(x => x >= 6).Count();
            double pourc6 = ((double)numberOfAgreement6 / (double)numbers.Count) * 100;
            String pourc6Str = "Rate of agreement (6/7) between evaluators is " + numberOfAgreement6 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc6) + "%";
            Console.WriteLine(pourc6Str);
            agreements.Add(pourc6Str);

            var numberOfAgreement5 = numbers.Where(x => x >= 5).Count();
            double pourc5 = ((double)numberOfAgreement5 / (double)numbers.Count) * 100;
            String pourc5Str = "Rate of agreement (5/7) between evaluators is " + numberOfAgreement5 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc5) + "%";
            Console.WriteLine(pourc5Str);
            agreements.Add(pourc5Str);

            var numberOfAgreement4 = numbers.Where(x => x >= 4).Count();
            double pourc4 = ((double)numberOfAgreement4 / (double)numbers.Count) * 100;
            string pourc4Str = "Rate of agreement (4/7) between evaluators is " + numberOfAgreement4 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc4) + "%";
            Console.WriteLine(pourc4Str);
            agreements.Add(pourc4Str);

            var numberOfAgreement3 = numbers.Where(x => x >= 3).Count();
            double pourc3 = ((double)numberOfAgreement3 / (double)numbers.Count) * 100;
            String pourc3Str = "Rate of agreement (3/7) between evaluators is " + numberOfAgreement3 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc3) + "%";
            Console.WriteLine(pourc3Str);
            agreements.Add(pourc3Str);
            return agreements;
        }

        public List<String> CheckAgreementSyntax(OntologyName? ontologyName)
        {
            List<String> agreements = new List<string>();

            List<int> numbers = new List<int>();
            List<Question> quest;
            if (ontologyName == null)
            {
                String titleAll = "Inter-rater Agreeement from AWO & STUFF & BIOTOP Ontology - Syntax";
                Console.WriteLine(titleAll);
                agreements.Add(titleAll);
                quest = this.Questions;
            }
            else
            {
                String titleAll = "Inter-rater Agreeement from "+ontologyName.ToString()+ " - Syntax";
                Console.WriteLine(titleAll);
                agreements.Add(titleAll);
                quest = this.Questions.Where(x => x.OntologyName == ontologyName).ToList();
            }

            String header = "Question;";
            int i = 1;
            foreach (var ev in this.Questions.FirstOrDefault().Evaluations)
            {
                header += "Evaluator" + i + ";";
                i++;
            }
            header += "Result;Frequency;";
            agreements.Add(header);

            foreach (var question in quest)
            {
                Quality winQual;
                int number;
                question.GetMostVotedQualityNumberSyn(out winQual, out number);
                String line = question.QuetisonStr + ";" + question.GetEvaluationsCSV(TypeEvaluation.SYNTAX) + winQual.ToString().ToUpper() + ";" + number;
                numbers.Add(number);
                agreements.Add(line);
                Console.WriteLine(line);
            }
            var numberOfAgreement6 = numbers.Where(x => x >= 6).Count();
            double pourc6 = ((double)numberOfAgreement6 / (double)numbers.Count) * 100;
            String pourc6Str = "Rate of agreement (6/7) between evaluators is " + numberOfAgreement6 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc6) + "%";
            Console.WriteLine(pourc6Str);
            agreements.Add(pourc6Str);

            var numberOfAgreement5 = numbers.Where(x => x >= 5).Count();
            double pourc5 = ((double)numberOfAgreement5 / (double)numbers.Count) * 100;
            String pourc5Str = "Rate of agreement (5/7) between evaluators is " + numberOfAgreement5 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc5) + "%";
            Console.WriteLine(pourc5Str);
            agreements.Add(pourc5Str);

            var numberOfAgreement4 = numbers.Where(x => x >= 4).Count();
            double pourc4 = ((double)numberOfAgreement4 / (double)numbers.Count) * 100;
            String pourc4Str = "Rate of agreement (4/7) between evaluators is " + numberOfAgreement4 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc4) + "%";
            Console.WriteLine(pourc4Str);
            agreements.Add(pourc4Str);

            var numberOfAgreement3 = numbers.Where(x => x >= 3).Count();
            double pourc3 = ((double)numberOfAgreement3 / (double)numbers.Count) * 100;
            String pourc3Str = "Rate of agreement (3/7) between evaluators is " + numberOfAgreement3 + "/" + numbers.Count
                + " ratio = " + String.Format("{0:0.00}", pourc3) + "%";
            Console.WriteLine(pourc3Str);
            agreements.Add(pourc3Str);
            return agreements;
        }

        
        public int GetCountAllSemantics()
        {
            int count = 0;
            foreach (var item in this.Questions)
            {
                count += item.GetCountEvaluations();
            }
            return count;
        }

        public int GetCountAllSyntax()
        {
            int count = 0;
            foreach (var item in this.Questions)
            {
                count += item.GetCountEvaluations();
            }
            return count;
        }

        public double GetEcartMeanSyntaxForInstance(Instance instance)
        {
            double ecartTotal = 0;
            foreach (var question in this.Questions)
            {
                double mean = question.GetMedianSyntaxLikert();//MoyenneLikertSyntax(instance);
                Evaluation evaluation = instance.GetEvaluation(question);
                double evalInstance = Utils.EchelleLikert(evaluation.Syntax);
                double ecart = Math.Abs(mean - evalInstance);
                ecartTotal += ecart;
            }
            return ecartTotal / (double)this.Questions.Count;
        }

        public double GetEcartMeanSemanticsForInstance(Instance instance)
        {
            double ecartTotal = 0;
            foreach (var question in this.Questions)
            {
                double mean = question.GetMedianSemanticsLikert();//.MoyenneLikertSemantics();
                Evaluation evaluation = instance.GetEvaluation(question);
                double evalInstance = Utils.EchelleLikert(evaluation.Semantics);
                double ecart = Math.Abs(mean - evalInstance);
                ecartTotal += ecart;
            }
            return ecartTotal / (double)this.Questions.Count;
        }


        public List<String> GetReportCountMedian(TypeEvaluation typeEvaluation)
        {
            List<String> report = new List<string>();

            int cVeryGood = 0, cGood = 0, cAverage = 0, cBad = 0, cVeryBad = 0;

            foreach (var question in this.Questions)
            {
                Quality q;
                if (typeEvaluation == TypeEvaluation.SYNTAX)
                {
                    q = question.GetMedianSyntax();
                }
                else q = question.GetMedianSemantics();

                switch (q)
                {
                    case Quality.VERY_GOOD:
                        cVeryGood++;
                        break;
                    case Quality.GOOD:
                        cGood++;
                        break;
                    case Quality.AVERAGE:
                        cAverage++;
                        break;
                    case Quality.BAD:
                        cBad++;
                        break;
                    case Quality.VERY_BAD:
                        cVeryBad++;
                        break;
                    case Quality.UNKNOWN:
                        break;
                    default:
                        break;
                }
            }
            Elements elements = new Elements();
            double pourcVeryGood = ((double)cVeryGood / (double)this.Questions.Count) * 100;
            report.Add("Very Good;" + cVeryGood + "/" + this.Questions.Count + ";" + String.Format("{0:0.00}", pourcVeryGood) + "%");
            Element eltVG = new Element { Label = "Very Good", Value = pourcVeryGood };
            elements.Add(eltVG);

            double pourcGood = ((double)cGood / (double)this.Questions.Count) * 100;
            report.Add("Good;" + cGood + "/" + this.Questions.Count + ";" + String.Format("{0:0.00}", pourcGood) + "%");
            Element eltG = new Element { Label = "Good", Value = pourcGood };
            elements.Add(eltG);

            double pourcAverage = ((double)cAverage / (double)this.Questions.Count) * 100;
            report.Add("Average;" + cAverage + "/" + this.Questions.Count + ";" + String.Format("{0:0.00}", pourcAverage) + "%");
            Element eltA = new Element { Label = "Average", Value = pourcAverage };
            elements.Add(eltA);

            double pourcBad = ((double)cBad / (double)this.Questions.Count) * 100;
            report.Add("Bad;" + cBad + "/" + this.Questions.Count + ";" + String.Format("{0:0.00}", pourcBad) + "%");
            Element eltB = new Element { Label = "Bad", Value = pourcBad };
            elements.Add(eltB);

            double pourcVeryBad = ((double)cVeryBad / (double)this.Questions.Count * 100);
            report.Add("Very Bad;" + cVeryBad + "/" + this.Questions.Count + ";" + String.Format("{0:0.00}", pourcVeryBad) + "%");
            Element eltVB = new Element { Label = "Very Bad", Value = pourcVeryBad };
            elements.Add(eltVB);

            report.Add("");
            report.AddRange(elements.GetPieLatex());

            return report;

        }


        public List<String> GetReportQuestionsSyntax()
        {
            List<String> report = new List<string>();

            foreach (var q in this.Questions)
            {
                String line = q.QuetisonStr + ";A=" + q.GetCountSyntaxQuality(Quality.VERY_GOOD)
                                            + ";B=" + q.GetCountSyntaxQuality(Quality.GOOD)
                                            + ";C=" + q.GetCountSyntaxQuality(Quality.AVERAGE)
                                            + ";D=" + q.GetCountSyntaxQuality(Quality.BAD)
                                            + ";E=" + q.GetCountSyntaxQuality(Quality.VERY_BAD)
                                            + ";" + q.MoyenneLikertSyntax() + ";" + q.GetEtenduSyntaxStr() + ";" + q.GetMedianSyntax();

                report.Add(line);
            }

            report.Add("");
            report.Add("Repartition Median - SYNTAX");
            report.AddRange(this.GetReportCountMedian(TypeEvaluation.SYNTAX));


            return report;
        }

        public List<String> GetReportQuestionsSemantics()
        {
            List<String> report = new List<string>();



            foreach (var q in this.Questions)
            {
                String line = q.QuetisonStr + ";A=" + q.GetCountSemanticsQuality(Quality.VERY_GOOD)
                                            + ";B=" + q.GetCountSemanticsQuality(Quality.GOOD)
                                            + ";C=" + q.GetCountSemanticsQuality(Quality.AVERAGE)
                                            + ";D=" + q.GetCountSemanticsQuality(Quality.BAD)
                                            + ";E=" + q.GetCountSemanticsQuality(Quality.VERY_BAD)
                                            + ";" + q.MoyenneLikertSemantics() + ";" + q.GetEtenduSemanticsStr() + ";" + q.GetMedianSemantics();

                report.Add(line);
            }
            report.Add("");
            report.Add("Repartition Median - SEMANTICS");
            report.AddRange(this.GetReportCountMedian(TypeEvaluation.SEMANTICS));
            return report;
        }

        public List<String> GetReportInstanceConfidenceSyntax()
        {
            List<String> report = new List<string>();
            report.Add("Report on Confidentiality of Syntax : ");
            Elements elements = new Elements();
            int indice = 1;
            foreach (var instance in this.Instances)
            {
                String sampleName = "Sample" + indice;
                double ecartMeanSyntax = this.GetEcartMeanSyntaxForInstance(instance);
                report.Add("Instance numero " + instance.Index + " (" + instance.Name + ") : inconfidence = " + ecartMeanSyntax);
                Element elt = new Element { Label = sampleName, Value = ecartMeanSyntax };
                elements.Add(elt);
                indice++;
            }

            report.Add("");
            report.AddRange(elements.GetHistoLatex());
            return report;
        }

        public List<String> GetReportInstanceConfidenceSemantics()
        {
            List<String> report = new List<string>();
            report.Add("Report on Confidentiality of Semantics : ");
            Elements elements = new Elements();
            foreach (var instance in this.Instances)
            {
                String label = "Sample" + (instance.Index + 1);
                double ecartMeanSyntax = this.GetEcartMeanSemanticsForInstance(instance);
                report.Add("Instance numero " + instance.Index + " (" + instance.Name + ") : inconfidence = " + ecartMeanSyntax);
                Element elt = new Element() { Label = label, Value = ecartMeanSyntax };
                elements.Add(elt);
            }
            report.Add("");
            report.AddRange(elements.GetHistoLatex());
            return report;
        }

        public void PrintReportCondifence()
        {
            foreach (var line in this.GetReportInstanceConfidenceSyntax())
            {
                Console.WriteLine(line);
            }
            Console.WriteLine();
            foreach (var line in this.GetReportInstanceConfidenceSemantics())
            {
                Console.WriteLine(line);
            }
        }

        public void SaveReportConfidence(string filename)
        {
            List<String> report = this.GetReportInstanceConfidenceSyntax();
            report.AddRange(this.GetReportInstanceConfidenceSemantics());
            File.WriteAllLines(filename, report);
        }
        public void SaveReportQuestionsSyntax(String filename)
        {
            File.WriteAllLines(filename, this.GetReportQuestionsSyntax());
        }

        public void SaveReportQuestionsSemantics(String filename)
        {
            File.WriteAllLines(filename, this.GetReportQuestionsSemantics());
        }
        public void SaveGeneralReport(String filename)
        {
            File.WriteAllLines(filename, this.GetReport());
        }
        public void PrintReportQuestions()
        {
            Console.WriteLine("Syntax report on the questions");
            foreach (var line in this.GetReportQuestionsSyntax())
            {
                Console.WriteLine(line);
            }

            Console.WriteLine("Semantics report on questions");
            foreach (var line in this.GetReportQuestionsSemantics())
            {
                Console.WriteLine(line);
            }
        }


        public List<String> GetReport()
        {
            List<String> report = new List<string>();
            int countTotal = this.Questions.Count;
            Elements elements = new Elements();

            report.Add("Stat -> Syntax");
            foreach (var qual in Utils.Qualities)
            {
                double pourc = ((double)this.GetCountSyntax(qual) / (double)this.GetCountAllSyntax()) * 100;
                String res = qual + ";" + this.GetCountSyntax(qual) + ";" + this.GetCountAllSyntax() + ";" + String.Format("{0:0.00}", pourc);
                elements.Add(new Element { Label = Utils.GetQualityStr(qual), Value = (double)this.GetCountSyntax(qual) });
                report.Add(res);
            }
            report.AddRange(elements.GetHistoLatex());
            report.Add("");
            report.Add("Stat -> Semantics");

            Elements elementsSem = new Elements();
            foreach (var qual in Utils.Qualities)
            {
                double pourc = ((double)this.GetCountSemantics(qual) / (double)this.GetCountAllSemantics()) * 100;
                String res = qual + ";" + this.GetCountSemantics(qual) + ";" + this.GetCountAllSemantics() + ";" + String.Format("{0:0.00}", pourc);
                elementsSem.Add(new Element { Label = Utils.GetQualityStr(qual), Value = (double)this.GetCountSemantics(qual) });
                report.Add(res);
            }
            report.AddRange(elementsSem.GetHistoLatex());
            return report;
        }

        public Question GetQuestion(int index)
        {
            foreach (var question in Questions)
            {
                if (index == question.Index)
                    return question;
            }
            return null;
        }

        public List<String> GetReportQuestionsWithMean(OntologyName ontologyName)
        {
            List<String> lst = new List<string>();

            List<Question> consideredQuestions = this.Questions.Where(x => x.OntologyName == ontologyName).ToList();

            lst.Add("Num;Question;Syntax;Semantics");

            var res = consideredQuestions.Select(x =>
            new
            {
                Number = x.Number,
                Sentence = x.QuetisonStr,
                SyntaxMean = x.GetMedianSyntax(),
                SemanticsMean = x.GetMedianSemantics(),
                SyntaxEchelleLikert = x.GetMedianSyntaxLikert() + x.GetMedianSemanticsLikert()
            }).OrderByDescending(x => x.SyntaxEchelleLikert).ToList();

            foreach (var item in res)
            {
                string sentence = item.Sentence;
                if (!sentence.EndsWith("?", StringComparison.CurrentCulture) && !sentence.EndsWith(".", StringComparison.CurrentCulture))
                    sentence += ".";
                String line = item.Number + ";" + sentence + ";" + Utils.GetQualityStr(item.SyntaxMean) + ";" + Utils.GetQualityStr(item.SemanticsMean);
                lst.Add(line);
            }
            return lst;
        }

        public void SaveReportQuestionsWithMean(String filename, OntologyName ontologyName)
        {
            File.WriteAllLines(filename, this.GetReportQuestionsWithMean(ontologyName));
        }

        public List<String> GetReportRecapMean(OntologyName ontologyName)
        {
            List<String> lst = new List<string>();

            List<Question> consideredQuestions = this.Questions.Where(x => x.OntologyName == ontologyName).ToList();

            Quality[] qualities = (Quality[])Enum.GetValues(typeof(Quality));

            lst.Add("Syntax");
            lst.Add("Quality;Count");
            foreach (var quality in qualities)
            {
                int count = consideredQuestions.Where(x => x.GetMedianSyntax() == quality).Count();

                String pourc = String.Format("{0:0.00}", ((double)count / (double)consideredQuestions.Count()) * 100);
                lst.Add(Utils.GetQualityStr(quality) + ";" + count + ";" + pourc + "%");
            }
            lst.Add("");
            lst.Add("Semantics");
            lst.Add("Quality;Count");
            foreach (var quality in qualities)
            {
                int count = consideredQuestions.Where(x => x.GetMedianSemantics() == quality).Count();

                String pourc = String.Format("{0:0.00}", ((double)count / (double)consideredQuestions.Count()) * 100);
                lst.Add(Utils.GetQualityStr(quality) + ";" + count + ";" + pourc + "%");
            }

            return lst;
        }

        public List<String> GetReportRecapMean()
        {
            List<String> lst = new List<string>();

            List<Question> consideredQuestions = this.Questions;

            Quality[] qualities = (Quality[])Enum.GetValues(typeof(Quality));

            lst.Add("Syntax");
            lst.Add("Quality;Count");
            foreach (var quality in qualities)
            {
                int count = consideredQuestions.Where(x => x.GetMedianSyntax() == quality).Count();

                String pourc = String.Format("{0:0.00}", ((double)count / (double)consideredQuestions.Count()) * 100);
                lst.Add(Utils.GetQualityStr(quality) + ";" + count + ";" + pourc + "%");
            }
            lst.Add("");
            lst.Add("Semantics");
            lst.Add("Quality;Count");
            foreach (var quality in qualities)
            {
                int count = consideredQuestions.Where(x => x.GetMedianSemantics() == quality).Count();

                String pourc = String.Format("{0:0.00}", ((double)count / (double)consideredQuestions.Count()) * 100);
                lst.Add(Utils.GetQualityStr(quality) + ";" + count + ";" + pourc + "%");
            }

            return lst;
        }

        public void PrintReport()
        {
            foreach (var item in this.GetReport())
            {
                Console.WriteLine(item);
            }
        }

        public void SaveReportRecapMeanOntology(String filename, OntologyName ontologyName)
        {
            File.WriteAllLines(filename, this.GetReportRecapMean(ontologyName));
        }

        public void SaveReportRecapMean(String filename)
        {
            File.WriteAllLines(filename, this.GetReportRecapMean());
        }
        public List<int> GetValuesOfEvaluator(TypeEvaluation typeEvaluation, int index)
        {
            return this.GetValuesOfEvaluator(typeEvaluation, index, null);
        }
        public List<int> GetValuesOfEvaluator(TypeEvaluation typeEvaluation, int index, OntologyName? ontologyName)
        {
            List<int> values = new List<int>();

            List<Question> concernedQuestions = this.Questions;

            if (ontologyName != null)
            {
                concernedQuestions = this.Questions.Where(x => x.OntologyName == ontologyName).ToList();
            }

            foreach (var question in concernedQuestions)
            {
                Dictionary<Quality, int> dicoQualities = new Dictionary<Quality, int>();
                dicoQualities.Add(Quality.VERY_GOOD, 4); //A 
                dicoQualities.Add(Quality.GOOD, 3);      //B
                dicoQualities.Add(Quality.AVERAGE, 2);   //C
                dicoQualities.Add(Quality.BAD, 1);       //D
                dicoQualities.Add(Quality.VERY_BAD, 0);  //E

                Evaluation evaluation = question.Evaluations[index];
                switch (typeEvaluation)
                {
                    case TypeEvaluation.SEMANTICS:
                        values.Add(dicoQualities[evaluation.Semantics]);
                        break;
                    case TypeEvaluation.SYNTAX:
                        values.Add(dicoQualities[evaluation.Syntax]);
                        break;
                    default:
                        break;
                }
            }
            return values;
        }
        public List<String> GetTableForR(String reportName, TypeEvaluation typeEvaluation, OntologyName? ontologyName)
        {
            List<String> names = new List<string>();
            List<String> lines = new List<string>();

            int index = 0;
            String dataFrame = "data" + reportName + " <- data.frame(";

            int instIndex = 1;
            foreach (var instance in this.Instances)
            {
                String name = instance.Name.Split('-', '.')[1];
                //String name = "Inst" + instIndex;
                instIndex++;
                String line = "";

                List<int> values = GetValuesOfEvaluator(typeEvaluation, index, ontologyName);

                line += name + reportName + "<-c(";

                for (int i = 0; i < values.Count - 1; i++)
                {
                    line += values[i] + ",";
                }
                line += values[values.Count - 1] + ")";
                lines.Add(line);
                index++;

                dataFrame += name + reportName + ",";
            }

            dataFrame = dataFrame.Substring(0, dataFrame.Length - 1) + ")";
            lines.Add(dataFrame);
            String final = "kappam.fleiss(data" + reportName + ", detail=TRUE)";
            lines.Add(final);
            return lines;
        }
        public void PrintTableForR(String reportName, TypeEvaluation typeEvaluation, OntologyName? ontologyName)
        {
            foreach (var item in GetTableForR(reportName, typeEvaluation, ontologyName))
            {
                Console.WriteLine(item);
            }
        }
        public void PrintTableForR(String reportName, TypeEvaluation typeEvaluation)
        {
            PrintTableForR(reportName, typeEvaluation, null);
        }
    }
}

