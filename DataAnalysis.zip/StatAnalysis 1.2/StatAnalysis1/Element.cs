﻿using System;
namespace StatAnalysis1
{
    public class Element
    {
        public String Label { get; set; }
        public double Value { get; set; }
        public Element()
        {
        }
        public String GetValueStr()
        {

            if (Math.Abs(this.Value - (double)((int)(this.Value))) < 0.0000001)
                return "" + this.Value;
            String valueStr = String.Format("{0:0.00}", this.Value);
            return valueStr;
        }

    }
}
