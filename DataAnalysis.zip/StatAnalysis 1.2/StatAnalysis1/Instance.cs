﻿using System;
using System.Linq;

namespace StatAnalysis1
{
    public class Instance
    {
        public String Filename { get; set; }
        public int Index { get; set; }
        public Experiment Experiment { get; set; }

        public Instance(String filename, int index)
        {
            this.Filename = filename;
            this.Index = index;
        }
        public String Name { get
            {
                String[] values = this.Filename.Split('/');
                return values[values.Length - 1];
            }
        }
        public Evaluation GetEvaluation (Question question)
        {
            return question.Evaluations[this.Index];
        }

        public Evaluation GetEvaluation(int indexQuestion)
        {
            Question question = this.Experiment.Questions.Where(x => x.Index == indexQuestion).FirstOrDefault();
            return this.GetEvaluation(question);
        }
    }
}
