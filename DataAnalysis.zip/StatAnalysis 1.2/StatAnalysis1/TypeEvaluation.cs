﻿using System;
namespace StatAnalysis1
{
    public enum TypeEvaluation
    {
        SYNTAX,
        SEMANTICS
    }
}
