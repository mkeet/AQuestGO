﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StatAnalysis1
{
    public class Question
    {
        public int Index { get; private set; }
        public String Line { get; private set; }
        public OntologyName OntologyName { get; private set; }
        public List<Evaluation> Evaluations { get; set; }

        public String GetEvaluationsCSV(TypeEvaluation typeEvaluation)
        {
            String str = "";
            foreach (var ev in this.Evaluations)
            {
                switch (typeEvaluation)
                {
                    case TypeEvaluation.SEMANTICS:
                        str += ev.Semantics.ToString().ToLower()+";";
                        break;

                    default:
                        str += ev.Syntax.ToString().ToLower() + ";";
                        break;
                }                
            }
            return str;
        }

        public String GetOrderedEvaluationsCSV(TypeEvaluation typeEvaluation)
        {
            String str = "";

            int mid = this.Evaluations.Count / 2;
            int i = 0;
            List<Evaluation> evas;
            if(typeEvaluation == TypeEvaluation.SYNTAX)
                evas = this.Evaluations.OrderBy(x => (int)x.Syntax).ToList();
            else evas = this.Evaluations.OrderBy(x => (int)x.Semantics).ToList();
            foreach (var ev in evas) 
            {
                switch (typeEvaluation)
                {
                    case TypeEvaluation.SEMANTICS:
                        if (i != mid)
                            str += ev.Semantics.ToString().ToLower() + ",";
                        else str += ev.Semantics.ToString().ToUpper() + ",";
                        break;

                    case TypeEvaluation.SYNTAX:
                        if (i != mid)
                            str += ev.Syntax.ToString().ToLower() + ",";
                        else str += ev.Syntax.ToString().ToUpper() + ",";
                        break;
                }
                i++;
            }
            return str;
        }

        public Question(int index, String line)
        {
            this.Index = index;
            this.Line = line;

            if ((this.Index >= 20)&& (this.Index <= 60))
            {
                this.OntologyName = OntologyName.AWO;
            }
            else if ((this.Index >= 62) && (this.Index <= 76))
            {
                this.OntologyName = OntologyName.STUFF;
            }
            else if ((this.Index >= 78) && (this.Index <= 124))
            {
                this.OntologyName = OntologyName.BIOTOP;
            }

            this.Evaluations = new List<Evaluation>();

            String[] elements = this.Line.Split(';',',');

            String[] quest = elements[0].Split('.');
            this.Number = quest[0];

            this.QuetisonStr = quest[1];
            if (quest.Length>2)
            {
                int i = 2;
                while (i<quest.Length)
                {
                    this.QuetisonStr += "." + quest[i];
                    i++;
                }
                
            }

            this.AddNewQualities(line);

            //Evaluation evaluation = new Evaluation(elements[1], elements[2]);
            //this.Evaluations.Add(evaluation);
            
            /*
            this.SyntaxQualities.Add(this.getQuality(elements[1]));
            this.SemanticQualities.Add(this.getQuality(elements[2]));
            */

        }

        public void AddNewQualities(String line)
        {
            String[] elements = line.Split(',');
            Evaluation evaluation = new Evaluation(elements[1], elements[2]);
            this.Evaluations.Add(evaluation);
            
        }

        
        public double MoyenneLikertSyntax()
        {
            double somme = 0;
            foreach (var evaluation in this.Evaluations)
            {
                somme += Utils.EchelleLikert(evaluation.Syntax);
            }
            return somme / (double)this.Evaluations.Count;
        }
        public double MoyenneLikertSyntax(Instance instance) // ito ihany no ohatran'io :-)
        {
            double somme = 0;
            int indexEvaluation = 0;
            foreach (var evaluation in this.Evaluations)
            {
                if(instance.Index == indexEvaluation)
                {
                    indexEvaluation++;
                    continue;
                }

                somme += Utils.EchelleLikert(evaluation.Syntax);
                indexEvaluation++;
            }
            return somme /( (double)this.Evaluations.Count-1);
        }

        public double MoyenneLikertSemantics()
        {
            double somme = 0;
            foreach (var evaluation in this.Evaluations)
            {
                somme += Utils.EchelleLikert(evaluation.Semantics);
            }
            return somme / (double)this.Evaluations.Count;
        }


        public double GetMedianSyntaxLikert()
        {
            Quality q = this.GetMedianSyntax();
            return Utils.EchelleLikert(q);
        }

        public double GetMedianSemanticsLikert()
        {
            Quality q = this.GetMedianSemantics();
            return Utils.EchelleLikert(q);
        }

        public Quality GetMedianSyntax()
        {
            List<int> listMaskMedian = new List<int>();
            foreach (var evaluation in this.Evaluations)
            {
                listMaskMedian.Add((int)Utils.EchelleLikert(evaluation.Syntax));
            }
            int maskMedian = Utils.GetMedian(listMaskMedian);
            return Utils.EchelleLikertToQuality(maskMedian);
        }

        public Quality GetMedianSemantics()
        {
            List<int> listMaskMedian = new List<int>();
            foreach (var evaluation in this.Evaluations)
            {
                listMaskMedian.Add((int)Utils.EchelleLikert(evaluation.Semantics));
            }
            int maskMedian = Utils.GetMedian(listMaskMedian);
            return Utils.EchelleLikertToQuality(maskMedian);
        }

        public String GetEtenduSyntaxStr()
        {
            return "["+this.EvaluationMaxSyntax + "-" + this.EvaluationMinSyntax + "]";
        }

        public String GetEtenduSemanticsStr()
        {
            return "[" + this.EvaluationMaxSemantics + "-" + this.EvaluationMinSemantics + "]";
        }

        public Quality EvaluationMinSyntax
        {
            get
            {
                double min = 100;
                foreach (var evaluation in this.Evaluations)
                {
                    if(Utils.EchelleLikert(evaluation.Syntax) < min)
                    {
                        min = Utils.EchelleLikert(evaluation.Syntax);
                    }
                }
                return Utils.EchelleLikertToQuality((int)min);
            }
        }
        public Quality EvaluationMaxSyntax
        {
            get
            {
                double max = 0;
                foreach (var evaluation in this.Evaluations)
                {
                    if (Utils.EchelleLikert(evaluation.Syntax) > max)
                    {
                        max = Utils.EchelleLikert(evaluation.Syntax);
                    }
                }
                return Utils.EchelleLikertToQuality((int)max);
            }
        }

        public Quality EvaluationMinSemantics
        {
            get
            {
                double min = 100;
                foreach (var evaluation in this.Evaluations)
                {
                    if (Utils.EchelleLikert(evaluation.Semantics) < min)
                    {
                        min = Utils.EchelleLikert(evaluation.Semantics);
                    }
                }
                return Utils.EchelleLikertToQuality((int)min);
            }
        }
        public Quality EvaluationMaxSemantics
        {
            get
            {
                double max = 0;
                foreach (var evaluation in this.Evaluations)
                {
                    if (Utils.EchelleLikert(evaluation.Semantics) > max)
                    {
                        max = Utils.EchelleLikert(evaluation.Semantics);
                    }
                }
                return Utils.EchelleLikertToQuality((int)max);
            }
        }



        public String Number { get; set; }

        public String QuetisonStr { get; set; }

        public int GetCountSyntaxQuality(Quality quality)
        {
            int result = this.Evaluations.Where(x => x.Syntax == quality).Count();
            return result;
        }

        public int GetCountSemanticsQuality(Quality quality)
        {
            int result = this.Evaluations.Where(x => x.Semantics == quality).Count();
            return result;
        }

        public int GetCountEvaluations()
        {
            int result = this.Evaluations.Count();
            return result;
        }

        public void GetMostVotedQualityNumberSem(out Quality quality, out int number)
        {
            Dictionary<Quality, int> dicoSem = new Dictionary<Quality, int>();
            var numberVG = this.Evaluations.Where(x => x.Semantics == Quality.VERY_GOOD).Count();
            dicoSem.Add(Quality.VERY_GOOD, numberVG);
            var numberG = this.Evaluations.Where(x => x.Semantics == Quality.GOOD).Count();
            dicoSem.Add(Quality.GOOD, numberG);
            var numberA = this.Evaluations.Where(x => x.Semantics == Quality.AVERAGE).Count();
            dicoSem.Add(Quality.AVERAGE, numberA);
            var numberB = this.Evaluations.Where(x => x.Semantics == Quality.BAD).Count();
            dicoSem.Add(Quality.BAD, numberB);
            var numberVB = this.Evaluations.Where(x => x.Semantics == Quality.VERY_BAD).Count();
            dicoSem.Add(Quality.VERY_BAD, numberVB);

            var resOrdSem = dicoSem.OrderByDescending(x => x.Value);
            var winnerSem = resOrdSem.FirstOrDefault();

            quality = winnerSem.Key;
            number = winnerSem.Value;
        }
        public void GetMostVotedQualityNumberSemTab(out List<Quality> qualities, out int number)
        {
            Dictionary<Quality, int> dicoSem = new Dictionary<Quality, int>();
            var numberVG = this.Evaluations.Where(x => x.Semantics == Quality.VERY_GOOD).Count();
            dicoSem.Add(Quality.VERY_GOOD, numberVG);
            var numberG = this.Evaluations.Where(x => x.Semantics == Quality.GOOD).Count();
            dicoSem.Add(Quality.GOOD, numberG);
            var numberA = this.Evaluations.Where(x => x.Semantics == Quality.AVERAGE).Count();
            dicoSem.Add(Quality.AVERAGE, numberA);
            var numberB = this.Evaluations.Where(x => x.Semantics == Quality.BAD).Count();
            dicoSem.Add(Quality.BAD, numberB);
            var numberVB = this.Evaluations.Where(x => x.Semantics == Quality.VERY_BAD).Count();
            dicoSem.Add(Quality.VERY_BAD, numberVB);

            var resOrdSem = dicoSem.OrderByDescending(x => x.Value);
            var winnerSem = resOrdSem.FirstOrDefault();

            number = winnerSem.Value;
            int n = number;
            
            qualities = resOrdSem.Where(x => x.Value == n).Select(x=>x.Key).ToList();
        }

        public void GetMostVotedQualityNumberSyn(out Quality quality, out int number)
        {
            Dictionary<Quality, int> dicoSyn = new Dictionary<Quality, int>();
            var numberVG = this.Evaluations.Where(x => x.Syntax == Quality.VERY_GOOD).Count();
            dicoSyn.Add(Quality.VERY_GOOD, numberVG);
            var numberG = this.Evaluations.Where(x => x.Syntax == Quality.GOOD).Count();
            dicoSyn.Add(Quality.GOOD, numberG);
            var numberA = this.Evaluations.Where(x => x.Syntax == Quality.AVERAGE).Count();
            dicoSyn.Add(Quality.AVERAGE, numberA);
            var numberB = this.Evaluations.Where(x => x.Syntax == Quality.BAD).Count();
            dicoSyn.Add(Quality.BAD, numberB);
            var numberVB = this.Evaluations.Where(x => x.Syntax == Quality.VERY_BAD).Count();
            dicoSyn.Add(Quality.VERY_BAD, numberVB);

            var resOrdSyn = dicoSyn.OrderByDescending(x => x.Value);
            var winnerSyn = resOrdSyn.FirstOrDefault();
            quality = winnerSyn.Key;
            number = winnerSyn.Value;
        }
        public void GetMostVotedQualityNumberSynTab(out List<Quality> qualities, out int number)
        {
            Dictionary<Quality, int> dicoSyn = new Dictionary<Quality, int>();
            var numberVG = this.Evaluations.Where(x => x.Syntax == Quality.VERY_GOOD).Count();
            dicoSyn.Add(Quality.VERY_GOOD, numberVG);
            var numberG = this.Evaluations.Where(x => x.Syntax == Quality.GOOD).Count();
            dicoSyn.Add(Quality.GOOD, numberG);
            var numberA = this.Evaluations.Where(x => x.Syntax == Quality.AVERAGE).Count();
            dicoSyn.Add(Quality.AVERAGE, numberA);
            var numberB = this.Evaluations.Where(x => x.Syntax == Quality.BAD).Count();
            dicoSyn.Add(Quality.BAD, numberB);
            var numberVB = this.Evaluations.Where(x => x.Syntax == Quality.VERY_BAD).Count();
            dicoSyn.Add(Quality.VERY_BAD, numberVB);

            var resOrdSyn = dicoSyn.OrderByDescending(x => x.Value);
            var winnerSyn = resOrdSyn.FirstOrDefault();
            number = winnerSyn.Value;
            int n = number;

            qualities = resOrdSyn.Where(x => x.Value == n).Select(x => x.Key).ToList();

        }

    }
}
