package Main;

// Imports
import java.util.ArrayList;
import java.util.Random;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

/**
 *
 * @author stevewang
 */
public class NormalQuestions {
    
    // private vairable declare for this class
    private static OWLOntologyManager manager;
    private static OWLOntology ontology;
    private static OWLDataFactory factory;
    private static OWLReasoner reasoner;
    private static OWLOntologyFormat format; 
    private static PrefixOWLOntologyFormat prefixFormat;
    private static PrefixManager prefixManager;
    private String sentence;
   
    /**
     * public constructor for normal questions 
     * @param manager
     * @param ontology
     * @param factory
     * @param reasoner
     * @param format
     * @param prefixFormat
     * @param prefixManager 
     */
    public NormalQuestions(OWLOntologyManager manager, OWLOntology ontology,OWLDataFactory factory,OWLReasoner reasoner,OWLOntologyFormat format, PrefixOWLOntologyFormat prefixFormat,PrefixManager prefixManager){
        this.manager = manager;
        this.ontology = ontology;
        this.factory = factory;
        this.reasoner = reasoner;
        this.format = format;
        this.prefixFormat = prefixFormat;
        this.prefixManager = prefixManager;
        sentence = "";
    }
    
    /**
     * Public method to generate normal questions 
     * @param template
     * @return
     * @throws OWLOntologyCreationException 
     */
    public String GenerateSentence(String template) throws OWLOntologyCreationException{
        // Initialise the output question to ""
        sentence = "";
        
        // Split the template to words and store it to an array
        String[] arr = template.split(" ");
        
        String token = "";
        // For each word in the array
        for (int i=0; i<arr.length; i++){
            String word = arr[i];
            String article = "";
            if (i!=0){
                article = arr[i-1];
            }
            
            // If the word is in the form <word>
            if (word.charAt(0)=='<' && word.charAt(word.length()-1)=='>'){
                
                token = word.substring(1, word.length()-1);
                
                sentence = ProcessToken(sentence, article , token);
                
            // If the word is in the form <word>? or <word>. etc..
            } else if (word.charAt(0)=='<' && word.charAt(word.length()-2)=='>'){
                
                token = word.substring(1, word.length()-2);
                
                sentence = ProcessToken(sentence, article , token) + word.charAt(word.length()-1);
            
            // If word is a normal word and is the first word int he sentence
            }else if (sentence.equals("")){
                sentence = word;
                
            // if word is a normal word and is not the first word in the sentence.
            }else{
                sentence = sentence + " " + word;
            }
        }
        return sentence; 
    }
    
    /**
     * It decides which form and type is the token and replace accordingly
     * @param output
     * @param article
     * @param token
     * @return
     * @throws OWLOntologyCreationException 
     */
    private static String ProcessToken(String output, String article , String token) throws OWLOntologyCreationException {
        // Split the token at ":" 
        // If there is no ":" in the token then the token only have one element in it 
        String [] subtokens = token.split(":");
        
        // if it is an ObjectProperty token without subObjectProperty specification
        if (subtokens[0].equals("ObjectProperty") && subtokens.length==1) {
            output = output + " " + selectObjectProperty();
        }
        // if it is an ObjectProperty token with an subObjectProperty specification
        else if (subtokens[0].equals("ObjectProperty") && subtokens.length==2){
            
            if (ontology.containsObjectPropertyInSignature(factory.getOWLObjectProperty(subtokens[1], prefixManager).getIRI())){
            output = output + " " + selectSubObjectPropertyOf(subtokens[1]);}
            else 
            {
                output = output + " <There are no such object property>";
            }
            
        // if it is an quantifier token
        } else if (token.equals("Quantifier")){
            if (oneOrZero() == 0) {
                output = output + " only";
            } else {
                output = output + " some";
            }
        
        // if it is a top class token
        }else if (subtokens[0].equals("Thing")){
            output = LinguisticHandler.checkArticle(output, article, subclassofTop());
        
        // In cases of any other tokens
        }else {
            // Substite <word> with something that is a subset of word in the ontology.
            output = LinguisticHandler.checkArticle(output, article , subToken(token));
        }
        return output;
    }
    
    /**
     * Select any object property in the ontology
     * @return 
     */
    private static String selectObjectProperty() {
        // Declare an arrayList to store all object properties
        ArrayList <String> allOP = new ArrayList<String>();
        
        // For all object property in the ontlogy, store it to the arraylist
        for (OWLObjectProperty obp : ontology.getObjectPropertiesInSignature()) {
            allOP.add(stringProcess(obp.toString()));
        }
        
        // Randomly select an object property
        String selectedOP = randomElementInTheList(allOP);
        return selectedOP;
    }
    
    /**
     * Randomly select a subObjectProperty of the given subtoken.
     * @param subtoken
     * @return 
     */
    private static String selectSubObjectPropertyOf(String subtoken) {
        ArrayList <String> allsubOP = new ArrayList<String>();
        
        OWLObjectProperty owlop = factory.getOWLObjectProperty(subtoken, prefixManager);
        for (Node<OWLObjectPropertyExpression> op: reasoner.getSubObjectProperties(owlop, false)) {
            allsubOP.add(stringProcess(op.getRepresentativeElement().toString()));
        }

        return randomElementInTheList(allsubOP);
    }
    
    /**
     * Generates either 0 or 1
     * @return 
     */
    private static int oneOrZero() {
        return (int) Math.round( Math.random() );
    }
    
    /**
     * get the top class of the ontology, usually is owl:Thing
     * @return String 
     */
    private static String subclassofTop() {
        // Declare a arraylist to store all subclasses of owl:Thing
        ArrayList <String> arr = new ArrayList<String>();
        
        // get the node owl:thing from the ontology
        OWLClassExpression topNode = reasoner.getTopClassNode().getRepresentativeElement();
        // For each of the subclasses of owl:thing, add it to the array list
        for (Node<OWLClass> owlce: reasoner.getSubClasses(topNode, false)){
            arr.add(stringProcess(owlce.getRepresentativeElement().toString()));
        }

        
        return randomElementInTheList(arr);
        
    }
    
    /**
     * substitute the given word with something that is a subset of word in the ontology.
     * @param word
     * @return String 
     * @throws OWLOntologyCreationException 
     */
    private static String subToken(String word) throws OWLOntologyCreationException {
        String newWord = "";
        
        
        // If word is in the ontology with IRI of the form 
        //"file:/Applications/Protege_4.1_beta/AfricanWildlifeOntology1.owl#word"
        if (ontology.containsClassInSignature(factory.getOWLClass(word, prefixManager).getIRI())) {
            
            newWord = replaceWithSubclassOf(word);
            
        }else{
            
            newWord = "<No such concept in ontology>";
        }
        
        return newWord;
    }
    
    /**
     * Processes the IRI in the from of either 
     * "file:/Applications/Protege_4.1_beta/AfricanWildlifeOntology1.owl#word"
     * or 
     * "#word"
     * to a String word
     * @param input
     * @return String
     */
    private static String stringProcess (String input){
        String output = "";
        
        // return only chars of the '#'
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            int x = input.indexOf('>');
            if (c == '#') {
                output = input.substring(i+1, x);
            }
        }
        output = output.replace("-", " ");
        output = output.toLowerCase();
        return output;
    }
    
    private static String randomElementInTheList(ArrayList<String> list){
        // randomly choose and return and class in the arraylist
        String choosenRepLacement = RandomSelect(list);
        // Since owl:Nothing is a subclass of anything
        // re-select if the chossen is owl:Nothing
        while (choosenRepLacement.equals("")){
            choosenRepLacement = RandomSelect(list);
        }
        return choosenRepLacement;
    }
    
    /**
     * Randomly selects an element from a given arraylist
     * @param subOptions
     * @return String
     */
    private static String RandomSelect(ArrayList<String> subOptions) {
        Random rand = new Random();
        return subOptions.get(rand.nextInt(subOptions.size()));
    }
    
    /**
     * Provides a subclass of the class with the given IRI 
     * @param iri
     * @return String
     * @throws OWLOntologyCreationException 
     */
    private static String replaceWithSubclassOf(String word) throws OWLOntologyCreationException {
        // Declare an empty arraylist that stores all subclasses of the given class 
        ArrayList<String> subOptions= new ArrayList <String> ();
        
        // Convert IRI to a OWLClassExpression
        OWLClassExpression owlcx = factory.getOWLClass(word, prefixManager);
        
        
        // Apply the reasoner and get all subclass of owlcx
        // For each OWLClass returned by the reasoner:
        for (Node<OWLClass> oc : reasoner.getSubClasses(owlcx, false)) {
            //Add the String repesentation of each OWLClass to the arrayList
            subOptions.add(stringProcess(oc.getRepresentativeElement().toString()));
        }
        
        return randomElementInTheList(subOptions);
        
    }
}
