package Main;

// Import
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;

/**
 *
 * @author stevewang
 */
public class Type2ResultSet {
    
    // Global Variables
    private static OWLClassExpression X;
    private static OWLClassExpression Y;
    
    /**
     * Constructor for type 2 result set with given variables
     * @param x
     * @param y 
     */
    public Type2ResultSet(OWLClassExpression x, OWLClassExpression y){
        
        this.X = x;
        this.Y = y;
    }
    
    /**
     * Construct a Type 2 results set with null value
     */
    public Type2ResultSet(){
        this.X = null;
        this.Y = null;
    }
    
    /**
     * Check if the result is null
     * @return 
     */
    public boolean isNull(){
        if (X==null || Y==null){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * Get OWLClassExpression X
     * @return 
     */
    public OWLClassExpression getX(){
        return X;
    }
    
    /**
     * Get OWLClassExpression Y
     * @return 
     */
    public OWLClassExpression getY(){
        return Y;
    }
}
