package Main;

// Import
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

/**
 *
 * @author stevewang
 */
public class Type5Question {
    
    //Global variables 
    private static OWLOntologyManager manager;
    private static OWLOntology ontology;
    private static OWLDataFactory factory;
    private static OWLReasoner reasoner;
    private static OWLOntologyFormat format; 
    private static PrefixOWLOntologyFormat prefixFormat;
    private static PrefixManager prefixManager;
    private String sentence;
    
    
    /**
     * Constructor for Type 1 questions (yes/No or True/false questions that requires 2 particulars and a object relation)
     * @param manager
     * @param ontology
     * @param factory
     * @param reasoner
     * @param format
     * @param prefixFormat
     * @param prefixManager 
     */
    public Type5Question(OWLOntologyManager manager, OWLOntology ontology,OWLDataFactory factory,OWLReasoner reasoner,OWLOntologyFormat format, PrefixOWLOntologyFormat prefixFormat,PrefixManager prefixManager){
        this.manager = manager;
        this.ontology = ontology;
        this.factory = factory;
        this.reasoner = reasoner;
        this.format = format;
        this.prefixFormat = prefixFormat;
        this.prefixManager = prefixManager;
        sentence = "";
    }
    
    /**
     * Generate Type 5 questions from a String template
     * @param template
     * @return 
     */
    public String GenerateQuestion (String template){
        // Declare output String to an empty String 
        String output = "";
        
        // Generate a String array with words in the template
        String [] words = template.split(" ");
        
        // Declare an arrayList to store the tokens in the template
        ArrayList <String> tokens = new ArrayList<String>();
        
        // For each word in the template, check if it is a token 
        // Tokens are in the form of <token>
        for (String word : words){
            
            // In cases of tokens in the middle of the sentence
            if (word.charAt(0)=='<' && word.charAt(word.length()-1)=='>'){
                tokens.add(word.substring(1, word.length()-1));
            
            // In cases of tokens at the end of the sentence
            }else if (word.charAt(0)=='<' && word.charAt(word.length()-2)=='>'){
                tokens.add(word.substring(1, word.length()-2));
                
            }
        }
        // ArrayList tokens in the form of [ OWLClass x , ObjectProperty ]
        
        // Declare results
        OWLClass classX;
        OWLObjectPropertyExpression objectProperty;
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(0).toLowerCase().equals("thing")){
            classX = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classX = factory.getOWLClass(tokens.get(0),prefixManager);
        }
        
        String [] opSplit = tokens.get(1).split(":");
        if (opSplit.length==1) {
            objectProperty = reasoner.getTopObjectPropertyNode().getRepresentativeElement();
        } else {
            objectProperty = factory.getOWLObjectProperty(opSplit[1], prefixManager);
        }
        
        // Put the sentence together from the template and the generated words
        Type5ResultSet result = getValidResultSet( classX , objectProperty );
        output = LinguisticHandler.generateType5Sentence( result , template );
        
        return output;
    }

    /**
     * Find a valid set of OWlClass X, OWLClass Y, OWLObjectProperty
     * @param classX
     * @param objectProperty
     * @return 
     */
    private Type5ResultSet getValidResultSet(OWLClass classX, OWLObjectPropertyExpression objectProperty) {
        
        // Declare arrayList to store all the possible result set
        ArrayList <OWLClass> xSet = new ArrayList<OWLClass>();
        ArrayList <OWLObjectPropertyExpression> opSet = new ArrayList<OWLObjectPropertyExpression>();
        
        // Get all subObjectProperties (sub-Relations) of the given object property
        ArrayList <OWLObjectPropertyExpression> subObjectProperty = getSubObjectPropertiesOf(objectProperty);
        
        // If there is subObjectProperty 
        if (!subObjectProperty.isEmpty()){
            
            // For every subObjectProperty 
            for (OWLObjectPropertyExpression owlope : subObjectProperty) {
                
                // Get all valid domain of subObjectProperty 
                OWLClass domain = validRandomDomain( owlope , classX );
                
                // If the domain is not null and the given object property has at least one range
                if ( domain != null && hasRange(objectProperty)){
                    
                    //Add the result to the declared list
                    xSet.add(domain);
                    opSet.add(owlope);
                }
            }
        
        // If there is no subObjectProperty, then use the given object property
        } else {
            
            // Get all valid ranges of ObjectProperty 
            OWLClass domain = validRandomDomain( objectProperty , classX );
            
            // If the domain is not null and the given object property has at least one range
            if ( domain != null && hasRange(objectProperty)){
                
                //Add the result to the declared list
                xSet.add(domain);
                opSet.add(objectProperty);
            }
        }
        
        
        // Randomly select a set of valid (X, R ) 
        Random rand = new Random();
        int index = rand.nextInt(xSet.size());
        return new Type5ResultSet(xSet.get(index), opSet.get(index));
    }
    
    /**
     * Randomly select a valid domain of the relation
     * A valid domain is defined as domain that is a subset of the given OWLClass X and it is not a OWL:Nothing OWLClass
     * @param owlope
     * @param classX
     * @return 
     */
    private OWLClass validRandomDomain(OWLObjectPropertyExpression owlope, OWLClass classX) {
        // Get all domians of the object property
        NodeSet<OWLClass> domainSet = reasoner.getObjectPropertyDomains(owlope, false);
        
        // Declare an ArrayList to store all valid domains
        ArrayList <OWLClass> newSet = new ArrayList<OWLClass>();
        
        // For each of the domain found
        for (Node<OWLClass> c: domainSet){
            
            // For each subclass of such domain
            for (Node<OWLClass> subclassOfC: reasoner.getSubClasses( c.getRepresentativeElement() , false)){
                
                // Domain is valid if it is a subclass of the token in the template and it is not OWL:Nothing object
                if ((reasoner.getSubClasses(classX, false).containsEntity(subclassOfC.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subclassOfC))){
                    newSet.add(subclassOfC.getRepresentativeElement());
                }
            }
            
            // If domain is a class and it does not have a subclass
            if ((c.getRepresentativeElement().isClassExpressionLiteral()) && (reasoner.getSubClasses(classX, false).containsEntity(c.getRepresentativeElement()))){
                newSet.add(c.getRepresentativeElement());
            }
        }
        
        // If there is no valid domains
        if (newSet.isEmpty()){
            return null;
            
        // Randomly select from the set of valid domains
        }else{
            return randomOWLClass(newSet);
        }
    }
    
    /**
     * Return all subObjectProperty of r
     * @param r
     * @return 
     */
    private ArrayList<OWLObjectPropertyExpression> getSubObjectPropertiesOf(OWLObjectPropertyExpression r) {
        // Declare an ArrayList to store all valid sub object properties
        ArrayList<OWLObjectPropertyExpression> results = new ArrayList<OWLObjectPropertyExpression>();
        
        // For each of the sub object property of r
        for(Node<OWLObjectPropertyExpression> ope: reasoner.getSubObjectProperties(r, false)){
            // The ope is not an OWL:Nothing object and it is not defined as an inverse of another object property
            if ((!reasoner.getBottomObjectPropertyNode().getRepresentativeElement().equals(ope.getRepresentativeElement()))&&isNotAnInverse(ope)){
                results.add(ope.getRepresentativeElement());
            }
        }
        return results;
    }

    /**
     * Check if the given object relation is not an inverse
     * @param ope
     * @return 
     */
    private boolean isNotAnInverse(Node<OWLObjectPropertyExpression> ope) {
        
        // A relation is an inverse if the string representation of it start with InverseOf
        OWLObjectPropertyExpression op = ope.getRepresentativeElement();
        String stringRep = op.toString();
        String [] sections = stringRep.split("\\(");
        if (sections[0].equals("InverseOf")){
            return false;
        }else{
            return true;
        }
    }
    
    /**
     * Randomly select an OWLClass from a list
     * @param List
     * @return 
     */
    private OWLClass randomOWLClass(ArrayList<OWLClass> List) {
        Random rand = new Random();
        return List.get(rand.nextInt(List.size()));
    }

    /**
     * Checks if the object property has at least one OWLClass range
     * @param objectProperty
     * @return 
     */
    private boolean hasRange(OWLObjectPropertyExpression objectProperty) {
        
        // Get all ranges 
        NodeSet<OWLClass> allRange = reasoner.getObjectPropertyRanges(objectProperty, false);
        Set<Node<OWLClass>> range = allRange.getNodes();
        // Remove OWL:Nothing for thr list
        range.remove(reasoner.getBottomClassNode());
        
        // If the ranges is empty then return false
        if (range.isEmpty()){
            return false;
            
        // Else return true
        }else{
            return true;
        }
    }


}
