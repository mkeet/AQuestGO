package Main;

// Imports
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

/**
 *
 * @author stevewang
 */
public class Type1Question {
    
    //Global variables 
    private static OWLOntologyManager manager;
    private static OWLOntology ontology;
    private static OWLDataFactory factory;
    private static OWLReasoner reasoner;
    private static OWLOntologyFormat format; 
    private static PrefixOWLOntologyFormat prefixFormat;
    private static PrefixManager prefixManager;
    private String sentence;
    
    
    /**
     * Constructor for Type 1 questions (yes/No or True/false questions that requires 2 particulars and a object relation)
     * @param manager
     * @param ontology
     * @param factory
     * @param reasoner
     * @param format
     * @param prefixFormat
     * @param prefixManager 
     */
    public Type1Question(OWLOntologyManager manager, OWLOntology ontology,OWLDataFactory factory,OWLReasoner reasoner,OWLOntologyFormat format, PrefixOWLOntologyFormat prefixFormat,PrefixManager prefixManager){
        this.manager = manager;
        this.ontology = ontology;
        this.factory = factory;
        this.reasoner = reasoner;
        this.format = format;
        this.prefixFormat = prefixFormat;
        this.prefixManager = prefixManager;
        sentence = "";
    }
    
    /**
     * Generate questions from a template of a question type 1
     * @param template
     * @return 
     */
    public String GenerateQuestion (String template){
        // Declare an array that stores each the words of the template
        String [] words = template.split(" ");
        
        // Declare an arrayList to store the 3 tokens in the template
        ArrayList <String> tokens = new ArrayList<String>();
        
        // Declare an arrayList to keep track where in the template is each of the tokens stored at
        ArrayList <Integer> tokenIndex = new ArrayList<Integer>();
        
        // For each word in the template, check if it is a token 
        // Tokens are in the form of <token>
        for (int i=0;i<words.length;i++){
            
            String word = words[i];
            
            // In cases of tokens in the middle of the sentence
            if (word.charAt(0)=='<' && word.charAt(word.length()-1)=='>'){
                tokens.add(word.substring(1, word.length()-1));
                tokenIndex.add(i);
            
            // In cases of tokens at the end of the sentence
            }else if (word.charAt(0)=='<' && word.charAt(word.length()-2)=='>'){
                tokens.add(word.substring(1, word.length()-2));
                tokenIndex.add(i);
            }
        }
        
        // For specicific types of object propert where tokens are in the form of <ObjectProperty:Verb>
        String [] OPsubtokens = tokens.get(1).split(":");
        
        // Declare results
        Type1ResultSet results;
        OWLClass classX;
        OWLClass classY;
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(0).toLowerCase().equals("thing")){
            classX = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classX = factory.getOWLClass(tokens.get(0),prefixManager);
        }
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(2).toLowerCase().equals("thing")){
            classY = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classY = factory.getOWLClass(tokens.get(2),prefixManager);
        }
        
        // In cases where there is not object property specified (i.e: <ObjectProperty>)
        if (OPsubtokens.length==1){
            results = getValidResultSet(classX,reasoner.getTopObjectPropertyNode().getRepresentativeElement(),classY);
        // In cases where the ontology is specified (i.e: <ObjectPropery:Verb>)
        }else{
            results = getValidResultSet(classX,factory.getOWLObjectProperty(OPsubtokens[1], prefixManager),classY);
        }
        
        // Put the sentence together from the template and the generated words
        sentence = LinguisticHandler.generateType1Sentence(words, tokenIndex, results);
        
        return sentence;
        
    }
    
    /**
     * Find a valid set of OWLClass X and OWLClass Y where is X is related to Y via the object property R
     * @param x
     * @param r
     * @param y
     * @return 
     */
    private Type1ResultSet getValidResultSet(OWLClass x, OWLObjectPropertyExpression r, OWLClass y) {
        // Declare an arrayList to store all the object property (relations) in the ontology
        ArrayList <OWLObjectPropertyExpression> allObjectProperties = getSubObjectPropertiesOf(r);
        
        // Declare a arrayLists to store all the possible domains, ranges and object properties from the ontology for the given template
        ArrayList <OWLClassExpression> resultX = new ArrayList<OWLClassExpression>();
        ArrayList <OWLClassExpression> resultY = new ArrayList<OWLClassExpression>();
        ArrayList <OWLObjectPropertyExpression> resultR = new ArrayList<OWLObjectPropertyExpression>();
        
        // For each each object property, randomly select a domain and range and if it is valid then store it 
        for (OWLObjectPropertyExpression e: allObjectProperties) {
            OWLClassExpression A = randomSelectDomain(e,x);
            OWLClassExpression B = randomSelectRange(e,y);
            if ((A!=null)&&(B!=null)){
                resultX.add(A);
                resultY.add(B);
                resultR.add(e);
            }
        }
        
        // Randomly select a set of valid (X, R, Y) 
        Random rand = new Random();
        int index = rand.nextInt(resultX.size());
        return new Type1ResultSet(resultX.get(index), resultY.get(index), resultR.get(index));
    }

    /**
     * Return all subObjectProperty of r
     * @param r
     * @return 
     */
    private ArrayList<OWLObjectPropertyExpression> getSubObjectPropertiesOf(OWLObjectPropertyExpression r) {
        // Declare an ArrayList to store all valid sub object properties
        ArrayList<OWLObjectPropertyExpression> results = new ArrayList<OWLObjectPropertyExpression>();
        
        // For each of the sub object property of r
        for(Node<OWLObjectPropertyExpression> ope: reasoner.getSubObjectProperties(r, false)){
            // The ope is not an OWL:Nothing object and it is not defined as an inverse of another object property
            if ((!reasoner.getBottomObjectPropertyNode().getRepresentativeElement().equals(ope.getRepresentativeElement()))&&isNotAnInverse(ope)){
                results.add(ope.getRepresentativeElement());
            }
        }
        return results;
    }

    /**
     * Randomly select a valid domain of the relation
     * @param e
     * @param x
     * @return 
     */
    private OWLClassExpression randomSelectDomain(OWLObjectPropertyExpression e, OWLClass x) {
        // Get all domians of the object property
        NodeSet<OWLClass> domainSet = reasoner.getObjectPropertyDomains(e, false);
        
        // Declare an ArrayList to store all valid domains
        ArrayList <OWLClassExpression> newSet = new ArrayList<OWLClassExpression>();
        
        // For each of the domain found
        for (Node<OWLClass> c: domainSet){
            
            // For each subclass of such domain
            for (Node<OWLClass> subclassOfC: reasoner.getSubClasses( c.getRepresentativeElement() , false)){
                
                // Domain is valid if it is a subclass of the token in the template and it is not OWL:Nothing object
                if ((reasoner.getSubClasses(x, false).containsEntity(subclassOfC.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subclassOfC))){
                    newSet.add(subclassOfC.getRepresentativeElement());
                }
            }
            
            // If domain is a class and it does not have a subclass
            if ((c.getRepresentativeElement().isClassExpressionLiteral()) && (reasoner.getSubClasses(x, false).containsEntity(c.getRepresentativeElement()))){
                newSet.add(c.getRepresentativeElement());
            }
        }
        
        // If there is no valid domains
        if (newSet.isEmpty()){
            return null;
            
        // Randomly select from the set of valid domains
        }else{
            return randomOWLClassExpression(newSet);
        }
    }
    
    /**
     * Randomly select a valid range of the relation
     * @param e
     * @param y
     * @return 
     */
    private OWLClassExpression randomSelectRange(OWLObjectPropertyExpression e, OWLClass y) {
        // Get all range of the object property
        NodeSet<OWLClass> rangeSet = reasoner.getObjectPropertyRanges(e, true);
        
        // Declare an ArrayList to store all valid ranges
        ArrayList <OWLClassExpression> newSet = new ArrayList<OWLClassExpression>();
        
        // For each of the range found
        for (Node<OWLClass> c: rangeSet){
            
            // For each subclass of the ranges
            for (Node<OWLClass> subclassOfC: reasoner.getSubClasses(c.getRepresentativeElement(), false)){
                
                // Range is valid if it is a subclass of the token from the template and it is not an OWL:Nothing object
                if ((reasoner.getSubClasses(y, false).containsEntity(subclassOfC.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subclassOfC))){
                    newSet.add(subclassOfC.getRepresentativeElement());
                }
            }
            
            // If the range is a class and has no subclasses
            if (c.getRepresentativeElement().isClassExpressionLiteral()&&reasoner.getSubClasses(c.getRepresentativeElement(), false).isEmpty()){
                newSet.add(c.getRepresentativeElement());
            }
        }
        
        // In case that there is not valid range
        if (newSet.isEmpty()){
            return null;
            
        // Randomly select from the valid ranges
        }else{
            return randomOWLClassExpression(newSet);
        }
    }

    /**
     * Randomly select an OWLClass from a list
     * @param List
     * @return 
     */
    private OWLClassExpression randomOWLClassExpression(ArrayList<OWLClassExpression> List) {
        Random rand = new Random();
        return List.get(rand.nextInt(List.size()));
    }

    /**
     * Check if the given object relation is not an inverse
     * @param ope
     * @return 
     */
    private boolean isNotAnInverse(Node<OWLObjectPropertyExpression> ope) {
        OWLObjectPropertyExpression op = ope.getRepresentativeElement();
        String stringRep = op.toString();
        String [] sections = stringRep.split("\\(");
        if (sections[0].equals("InverseOf")){
            return false;
        }else{
            return true;
        }
    }



    
    
}
