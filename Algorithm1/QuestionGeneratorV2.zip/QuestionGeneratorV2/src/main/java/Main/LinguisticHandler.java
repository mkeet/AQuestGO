package Main;

import java.util.ArrayList;

/**
 *
 * @author stevewang
 */
public class LinguisticHandler {
        
    /**
     * Assuming all articles in the template is either "The" or "a"
     * replace "a" with "an" if the word follows starts with a vow
     * otherwise append " "+newWord to the sentence
     * and return the new sentence
     * @param output
     * @param newWord
     * @return new sentence
     */
    public static String checkArticle(String output, String article,String newWord) {
        //if the newWord strats with a vow and the article before it is not "The" or "the"
        if (checkVow(newWord) && (article.equals("a")|| article.equals("A") ) ) {
            // Change the article to "an"
            output = output.substring(0, output.length()-1) + "an "+newWord;
        } else if (article.equals("")){
            String firstLetter = ""+newWord.charAt(0);
            output = firstLetter.toUpperCase()+newWord.substring(1);
        }else{
            output = output + " " + newWord; 
        }
        return output;
    }
    
    /**
     * Checks if the given word starts with a vow or not
     * @param word
     * @return boolean: true if word starts with a vow and
     * false if the word doesn't start with a vow
     */
    public static boolean checkVow(String word){
        if (word.charAt(0)=='a' || word.charAt(0)=='e' || word.charAt(0)=='i' || word.charAt(0)=='o' || word.charAt(0)=='u'
                || word.charAt(0)=='A' || word.charAt(0)=='E' || word.charAt(0)=='I' || word.charAt(0)=='O' || word.charAt(0)=='U') {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Process String representations of OWLClass and OWLObjectPorperty to understandable word
     * @param input
     * @return 
     */
    public static String stringProcess (String input){
        String output = "";
        
        // return only chars of the '#'
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            int x = input.indexOf('>');
            if (c == '#') {
                output = input.substring(i+1, x);
            }
        }
        
        output = output.replace("-", " ");
        output = output.toLowerCase();
        return output;
    }
    
    /**
     * Sentence generation for type 1 questions: True/False or Yes/No question with 2 particulars and a single relation
     * Given the template in form of the array, token indices and results that will replace the tokens
     * @param words
     * @param tokenIndex
     * @param results
     * @return 
     */
    public static String generateType1Sentence(String[] words, ArrayList<Integer> tokenIndex, Type1ResultSet results) {
        // Iniciate an empty output 
        String output = "";
        
        // For each token replace the right result in the right place in the template.
        for (int i = 0; i < tokenIndex.size(); i++) {
            int index = tokenIndex.get(i);
            if (i==0){
                words[index]= stringProcess(results.getX().toString());
            }else if (i==1){
                words[index]= stringProcess(results.getOP().toString());
            } else if (index==words.length-1){
                words[index]= stringProcess(results.getY().toString())+words[index].charAt(words[index].length()-1);
            } else {
                words [index] = stringProcess(results.getY().toString());
            }
        }
        
        // Add words to the output and check the article is correct
        for (int j=0; j<words.length; j++){
            String article = "";
            if (j!=0){
                article = words[j-1];
            }
            if (output.equals("")){
                output = words[j];
            }else{
                output = checkArticle(output, article, words[j]);
            }
        }
        
        // Make sure that the sentence starts with a capital letter
        String firstLetter = ""+output.charAt(0);
        output = firstLetter.toUpperCase()+output.substring(1);
        return output;
    }
    
    /**
     * Sentence generation for type 2 questions: True/False or Yes/No question with a single particulars and a single relation
     * Given the template in form of the array, token indices and results that will replace the tokens
     * @param words
     * @param tokenIndex
     * @param results
     * @return 
     */
    public static String generateType2Sentence(String[] words, ArrayList<Integer> tokenIndex, Type2ResultSet results) {
        // Iniciate output string
        String output = "";
        
        // For each token replace tokens with results in the correct places of the tempate
        for (int i = 0; i < tokenIndex.size(); i++) {
            int index = tokenIndex.get(i);
            if (i==0){
                words[index]=stringProcess(results.getX().toString());
            } else if (index==words.length-1){
                words[index]=stringProcess(results.getY().toString())+words[index].charAt(words[index].length()-1);
            } else {
                words [index] = stringProcess(results.getY().toString());
            }
        }
        
        // For check that the sentence has the correct articles
        for (int j=0; j<words.length; j++){
            String article = "";
            if (j!=0){
                article = words[j-1];
            }
            if (output.equals("")){
                output = words[j];
            }else{
                output = checkArticle(output, article, words[j]);
            }
        }
        
        // Make sure that the sentence starts with capital letters
        String firstLetter = ""+output.charAt(0);
        output = firstLetter.toUpperCase()+output.substring(1);
        return output;
    }
    
    /**
     * Sentence generation for type 3 questions: Quantified Yes/No or True/False questions
     * Given the result set and the template
     * @param result
     * @param template
     * @return 
     */
    public static String generateType3Sentence(Type3ResultSet result, String template) {
        // Initiate the output string to noting 
        String line = "";
        
        // Create a String array that contains only the words of the sentence.
        String [] words = template.split(" ");
        
        // Initial the article to nothing 
        String article = "";
        
        // Create integer count to keep track of which part of the result to be used
        int count = 0;
        
        // For each for in the words array 
        for (int i = 0; i<words.length; i++) {
            
            // Update the article to the previous word
            if (i!=0){
                article = words[i-1];
            }
            
            // If the word is a token in the middle of the sentence
            if (words[i].charAt(0)=='<' && words[i].charAt(words[i].length()-1)=='>'){
                
                // Check the article and replace with the correction section of the result 
                line = checkArticle(line, article, subType3Word(count, result));
                count ++;
                
            // If the word is a token at the end of the sentence
            }else if (words[i].charAt(0)=='<' && words[i].charAt(words[i].length()-2)=='>'){
                
                // Check the article and replace with the correction section of the result 
                line = checkArticle(line, article, subType3Word(count, result)) + words[i].charAt(words[i].length()-1);
                count ++;
            
            // If it is the first word in the sentence
            }else if (line.equals("")){
                line = words[i];
            
            // if it is any other word
            }else{
                line = line + " " + words[i];
            }
        }
        
        // Make sure the first word in the sentence is a capital letter
        String firstLetter = ""+line.charAt(0);
        line = firstLetter.toUpperCase()+line.substring(1);
        return line;
    }
    

    /**
     * Sentence generation for type 4 questions: What questions with 2 particulars and a single object property (relation)
     * Given the result set and the template 
     * @param result
     * @param template
     * @return 
     */
    public static String generateType4Sentence(Type1ResultSet result, String template) {
        // Initiat the output to an empty String 
        String line = "";
        
        // Create a String array that contains only the words of the sentence.
        String [] words = template.split(" ");
        
        // Initiate article to an empty string 
        String article = "";
        
        // Create a counter to keep track of which part of the result to use
        int count = 0;
        
        // For each word in the tempate 
        for (int i = 0; i<words.length; i++) {
            
            // Update the article to the previous word
            if (i!=0){
                article = words[i-1];
            }
            
            // For token in the midddle of the sentence 
            if (words[i].charAt(0)=='<' && words[i].charAt(words[i].length()-1)=='>'){
                
                // Check the article and replace token with the appropriate part of the result
                line = checkArticle(line, article, subType4Word(count, result));
                count ++;
                
            // For token at the end of the sentence
            }else if (words[i].charAt(0)=='<' && words[i].charAt(words[i].length()-2)=='>'){
                
                // Check the article and replace token with the appropriate part of the result
                line = checkArticle(line, article, subType4Word(count, result)) + words[i].charAt(words[i].length()-1);
                count ++;
                
            // If it is the first word in the sentence
            }else if (line.equals("")){
                line = words[i];
                
            // If it is any other word
            }else{
                line = line + " " + words[i];
            }
        }
        
        // Make sure that the sentence starts with a captial letter
        String firstLetter = ""+line.charAt(0);
        line = firstLetter.toUpperCase()+line.substring(1);
        return line;
    }

    /**
     * Sentence generation for type 5 questions: What questions with 1 particular and a single object property (relation)
     * Given the result set and the template 
     * @param result
     * @param template
     * @return 
     */
    public static String generateType5Sentence(Type5ResultSet result, String template) {
        // Initate the output to an empty String 
        String line = "";
        
        // Create a String array that contains only the words of the sentence.
        String [] words = template.split(" ");
        
        // Initiate article to an empty string
        String article = "";
        
        // Create a counter to keep track of which part of the result to use
        int count = 0;
        
        // For each word in the tempate
        for (int i = 0; i<words.length; i++) {
            
            // Update the article to the previous word
            if (i!=0){
                article = words[i-1];
            }
            
            // For token in the midddle of the sentence 
            if (words[i].charAt(0)=='<' && words[i].charAt(words[i].length()-1)=='>'){
                
                // Check the article and replace token with the appropriate part of the result
                line = checkArticle(line, article, subType5Word(count, result));
                count ++;
                
            // For token at the end of the sentence
            }else if (words[i].charAt(0)=='<' && words[i].charAt(words[i].length()-2)=='>'){
                
                // Check the article and replace token with the appropriate part of the result
                line = checkArticle(line, article, subType5Word(count, result)) + words[i].charAt(words[i].length()-1);
                count ++;
                
            // If it is the first word of the sentence
            }else if (line.equals("")){
                line = words[i];
            
            // If it is any other word
            }else{
                
                line = line + " " + words[i];
            }
        }
        
        // Make sure that the first word of the sentence is a capital letter
        String firstLetter = ""+line.charAt(0);
        line = firstLetter.toUpperCase()+line.substring(1);
        return line;
    }


    /**
     * Determine which part of the result to substitude in 
     * for question type 3
     * @param count
     * @param result
     * @return 
     */
    private static String subType3Word(int count, Type3ResultSet result) {
        // Type 3 result set is in the format of :
        // OWLClass X, OWLClass Y, OWLObjectProperty objectProperty, String Quantifier
        
        // If count is 0 then return OWLCLass X
        if (count == 0 ) {
            return stringProcess(result.getX().toString());
            
        // If count is 1 then return OWLObjectProperty objectProperty 
        } else if (count == 1 ) {
            return stringProcess(result.getOP().toString());
            
        // If count is 2 then return String quantifier
        } else if (count == 2 ) {
            return result.getQuantifier();
            
        // If count is 3 the return OWLClass Y
        } else if (count == 3 ) {
            return stringProcess(result.getY().toString());
            
        // If anything else then it is an invalid token
        } else{
            return "<invalid>";
        }
    }
    
    /**
     * Determine which part of the result to substitude in 
     * for question type 4
     * @param count
     * @param result
     * @return 
     */
    private static String subType4Word(int count, Type1ResultSet result) {
        // Type 4 question makes uses of type 1 result set is in the format of : 
        // OWLClass X, OWLObjectProperty objectProperty, OWLClass Y
        
        // If count is 0, then return OWLClass X
        if (count == 0 ) {
            return stringProcess(result.getX().toString());
            
        // If count is 1, then return OWLObjectProperty objectProperty
        } else if (count == 1 ) {
            return stringProcess(result.getOP().toString());
            
        // If count is 2, then return OWLClass Y
        } else if (count == 2 ) {
            return stringProcess(result.getY().toString());
           
        // If count is anything else, then the token is invalid.
        } else{
            return "<invalid>";
        }
    }
    
    /**
     * Determine which part of the result to substitude in 
     * for question type 5
     * @param count
     * @param result
     * @return 
     */
    private static String subType5Word(int count, Type5ResultSet result) {
        // Type 5 result set in the format: 
        // OWLClass X, OWLObjectProject objectProperty
        
        // If count is 0 then return OWLClass X
        if (count == 0 ) {
            return stringProcess(result.getX().toString());
        
        // If count is 1 then return OWLObjectProperty objectProperty
        } else if (count == 1 ) {
            return stringProcess(result.getOP().toString());
            
        // If count is anything else, then token is invalid.
        } else{
            return "<invalid>";
        }
    }
    
}
