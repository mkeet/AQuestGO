package Main;

// Imports
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;
import java.util.Set;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

/**
 *
 * @author stevewang
 */
public class Type4Question {

    //Global variables 
    private static OWLOntologyManager manager;
    private static OWLOntology ontology;
    private static OWLDataFactory factory;
    private static OWLReasoner reasoner;
    private static OWLOntologyFormat format; 
    private static PrefixOWLOntologyFormat prefixFormat;
    private static PrefixManager prefixManager;
    private String sentence;
    
    /**
     * Constructor for Type 1 questions (yes/No or True/false questions that requires 2 particulars and a object relation)
     * @param manager
     * @param ontology
     * @param factory
     * @param reasoner
     * @param format
     * @param prefixFormat
     * @param prefixManager 
     */
    public Type4Question(OWLOntologyManager manager, OWLOntology ontology,OWLDataFactory factory,OWLReasoner reasoner,OWLOntologyFormat format, PrefixOWLOntologyFormat prefixFormat,PrefixManager prefixManager){
        this.manager = manager;
        this.ontology = ontology;
        this.factory = factory;
        this.reasoner = reasoner;
        this.format = format;
        this.prefixFormat = prefixFormat;
        this.prefixManager = prefixManager;
        sentence = "";
    }
    
    /**
     * Generate Type 3 questions from a String template
     * @param template
     * @return 
     */
    public String GenerateQuestion(String template){
        
        // Declare output String to an empty String 
        String output = ""; 
        
        // Generate a String array with words in the template
        String [] words = template.split(" ");
        
        // Declare an arrayList to store the tokens in the template
        ArrayList <String> tokens = new ArrayList<String>();
        
        // For each word in the template, check if it is a token 
        // Tokens are in the form of <token>
        for (String word : words){
            
            // In cases of tokens in the middle of the sentence
            if (word.charAt(0)=='<' && word.charAt(word.length()-1)=='>'){
                tokens.add(word.substring(1, word.length()-1));
            
            // In cases of tokens at the end of the sentence
            }else if (word.charAt(0)=='<' && word.charAt(word.length()-2)=='>'){
                tokens.add(word.substring(1, word.length()-2));
                
            }
        }
        // ArrayList tokens in the format of [ClassX , objectProperty OR objectProperty:verb, ClassY]
        
        // Declare results
        OWLClass classX;
        OWLClass classY;
        OWLObjectPropertyExpression objectProperty;
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(0).toLowerCase().equals("thing")){
            classX = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classX = factory.getOWLClass(tokens.get(0),prefixManager);
        }
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(2).toLowerCase().equals("thing")){
            classY = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classY = factory.getOWLClass(tokens.get(2),prefixManager);
        }
        
        String [] opSplit = tokens.get(1).split(":");
        if (opSplit.length==1) {
            objectProperty = reasoner.getTopObjectPropertyNode().getRepresentativeElement();
        } else {
            objectProperty = factory.getOWLObjectProperty(opSplit[1], prefixManager);
        }
        
        // Put the sentence together from the template and the generated words
        Type1ResultSet result = getValidResultSet( classX , objectProperty , classY);
        output = LinguisticHandler.generateType4Sentence(result,template);
        return output;
    }

    /**
     * Find a valid set of OWlClass X, OWLClass Y, OWLObjectProperty objectProperty
     * @param classX
     * @param objectProperty
     * @param classY
     * @return 
     */
    private Type1ResultSet getValidResultSet(OWLClass classX, OWLObjectPropertyExpression objectProperty, OWLClass classY) {
        
        // Declare arrayList to store all the possible result set
        ArrayList <OWLClass> xSet = new ArrayList<OWLClass>();
        ArrayList <OWLClass> ySet = new ArrayList<OWLClass>();
        ArrayList <OWLObjectPropertyExpression> opSet = new ArrayList<OWLObjectPropertyExpression>();
        
        // Get all subObjectProperties (sub-Relations) of the given object property
        ArrayList<OWLObjectPropertyExpression> subObjectProperty = getSubObjectPropertiesOf( objectProperty );
        
        // If there is subObjectProperty 
        if (!subObjectProperty.isEmpty()){
            
            // For each subObjectProperty 
            for (OWLObjectPropertyExpression owlope : subObjectProperty) {
                
                // Get a randomly selected valid domain
                OWLClass domain = validRandomDomains( owlope , classX );
                
                // Get a ramdomly selected valid Ranges
                OWLClass range = validRandomRanges( owlope , classY);
                
                // If there exists such valid result set
                if ( domain != null && range != null){
                    
                    // Store the result
                    xSet.add(domain);
                    ySet.add(range);
                    opSet.add(owlope);
                }
            }
        
        // If there is no such subObjectProperty, the use the given object property
        } else {
            
            // Get a randomly selected valid domain
            OWLClass domain = validRandomDomains( objectProperty , classX );
            
            // Get a randomly selected valid range
            OWLClass range = validRandomRanges( objectProperty , classY);
            
            // If there exists such valid result set
            if ( domain != null && range != null){
                
                // Store the result
                xSet.add(domain);
                ySet.add(range);
                opSet.add(objectProperty);
            }
        }
        
        // Randomly select a set of valid (X, R, Y) 
        Random rand = new Random();
        int index = rand.nextInt(xSet.size());
        return new Type1ResultSet(xSet.get(index), ySet.get(index), opSet.get(index));
    }
    
    /**
     * Randomly select a valid domain for the given object property
     * A valid domain is defined as a domain that is a subclass of class X and is not an OWLClass:Nothing
     * @param owlope
     * @param classX
     * @return 
     */
    private OWLClass validRandomDomains(OWLObjectPropertyExpression owlope, OWLClass classX) {
        // Declare an empty arraylist to store valid domain
        ArrayList <OWLClass> results = new ArrayList<OWLClass>();
        
        // Get all subclasses of ClassX
        NodeSet <OWLClass> validClasses = reasoner.getSubClasses(classX, false);
        
        // Get all domain of given objectProperty
        NodeSet <OWLClass> allDomain = reasoner.getObjectPropertyDomains(owlope, false);
        
        // For all domain found
        for (Node<OWLClass> domain : allDomain){
            
            // For each subclass of the domain
            for (Node<OWLClass> subDomain : reasoner.getSubClasses(domain.getRepresentativeElement(), false)){
                
                // Get all subclasses of the domain (i.e: subdomains)
                NodeSet <OWLClass> subsubDomain = reasoner.getSubClasses(subDomain.getRepresentativeElement(),false);
                Set<Node<OWLClass>> x = subsubDomain.getNodes();
                
                // Remove OWL:Nothing from the set of subdomains
                x.remove(reasoner.getBottomClassNode());
                
                // If the sub-domains is a subclass of the given OWLClass X
                if ((validClasses.containsEntity(subDomain.getRepresentativeElement())) && (!reasoner.getBottomClassNode().equals(subDomain)) && (!x.isEmpty())){
                    
                    // Add the valid results to the arrayList
                    results.add(subDomain.getRepresentativeElement());
                }
            }
        }
        
        // In case that there is not valid range
        if (results.isEmpty()){
            return null;
            
        // Randomly select from the valid ranges
        } else {
            return randomOWLClass(results);
        }
    }
    
    /**
     * Randomly select a valid range
     * A range is valid if it is a subclass of the given OWLClass Y and it is not an OWL:Nothing class
     * @param subObjectProperty
     * @param classY
     * @return 
     */
    private OWLClass validRandomRanges(OWLObjectPropertyExpression subObjectProperty, OWLClass classY) {
        // Get all range of the object property
        NodeSet<OWLClass> rangeSet = reasoner.getObjectPropertyRanges(subObjectProperty, true);
        
        // Declare an ArrayList to store all valid ranges
        ArrayList <OWLClass> newSet = new ArrayList<OWLClass>();
        
        // For each of the range found
        for (Node<OWLClass> c: rangeSet){
            
            // For each subclass of the ranges
            for (Node<OWLClass> subclassOfC: reasoner.getSubClasses(c.getRepresentativeElement(), false)){
                
                // Range is valid if it is a subclass of the token from the template and it is not an OWL:Nothing object
                if ((reasoner.getSubClasses(classY, false).containsEntity(subclassOfC.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subclassOfC))){
                    newSet.add(subclassOfC.getRepresentativeElement());
                }
            }
            
            // If the range is a class and has no subclasses
            if (c.getRepresentativeElement().isClassExpressionLiteral()&&reasoner.getSubClasses(c.getRepresentativeElement(), false).isEmpty()){
                newSet.add(c.getRepresentativeElement());
            }
        }
        
        // In case that there is not valid range
        if (newSet.isEmpty()){
            return null;
            
        // Randomly select from the valid ranges
        }else{
            return randomOWLClass(newSet);
        }
    }
    
    /**
     * Return all subObjectProperty of r
     * @param r
     * @return 
     */
    private ArrayList<OWLObjectPropertyExpression> getSubObjectPropertiesOf(OWLObjectPropertyExpression r) {
        
        // Declare an ArrayList to store all valid sub object properties
        ArrayList<OWLObjectPropertyExpression> results = new ArrayList<OWLObjectPropertyExpression>();
        
        // For each of the sub object property of r
        for(Node<OWLObjectPropertyExpression> ope: reasoner.getSubObjectProperties(r, false)){
            // The ope is not an OWL:Nothing object and it is not defined as an inverse of another object property
            if ((!reasoner.getBottomObjectPropertyNode().getRepresentativeElement().equals(ope.getRepresentativeElement()))&&isNotAnInverse(ope)){
                results.add(ope.getRepresentativeElement());
            }
        }
        return results;
    }

    /**
     * Check if the given object relation is not an inverse
     * @param ope
     * @return 
     */
    private boolean isNotAnInverse(Node<OWLObjectPropertyExpression> ope) {
        OWLObjectPropertyExpression op = ope.getRepresentativeElement();
        String stringRep = op.toString();
        String [] sections = stringRep.split("\\(");
        if (sections[0].equals("InverseOf")){
            return false;
        }else{
            return true;
        }
    }

    /**
     * Randomly select an OWLClass from a list
     * @param List
     * @return 
     */
    private OWLClass randomOWLClass(ArrayList<OWLClass> List) {
        Random rand = new Random();
        return List.get(rand.nextInt(List.size()));
    }

}
