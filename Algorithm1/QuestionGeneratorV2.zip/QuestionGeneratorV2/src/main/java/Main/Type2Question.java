package Main;

// Import
import java.util.ArrayList;
import java.util.Random;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

/**
 *
 * @author stevewang
 */
public class Type2Question {
    
    //Global variables 
    private static OWLOntologyManager manager;
    private static OWLOntology ontology;
    private static OWLDataFactory factory;
    private static OWLReasoner reasoner;
    private static OWLOntologyFormat format; 
    private static PrefixOWLOntologyFormat prefixFormat;
    private static PrefixManager prefixManager;
    private String sentence;
    
    
    /**
     * Constructor for Type 2 questions (yes/No or True/false questions that requires 1 endurant and a perdurant)
     * @param manager
     * @param ontology
     * @param factory
     * @param reasoner
     * @param format
     * @param prefixFormat
     * @param prefixManager 
     */
    public Type2Question(OWLOntologyManager manager, OWLOntology ontology,OWLDataFactory factory,OWLReasoner reasoner,OWLOntologyFormat format, PrefixOWLOntologyFormat prefixFormat,PrefixManager prefixManager){
        this.manager = manager;
        this.ontology = ontology;
        this.factory = factory;
        this.reasoner = reasoner;
        this.format = format;
        this.prefixFormat = prefixFormat;
        this.prefixManager = prefixManager;
        sentence = "";
    }
    
    /**
     * Generate questions from a template of a question type 1
     * @param template
     * @return 
     */
    public String GenerateQuestion (String template){
        // Declare an array that stores each the words of the template
        String [] words = template.split(" ");
        
        // Declare an arrayList to store the 2 tokens in the template
        ArrayList <String> tokens = new ArrayList<String>();
        
        // Declare an arrayList to keep track where in the template is each of the tokens stored at
        ArrayList <Integer> tokenIndex = new ArrayList<Integer>();
        
        // For each word in the template, check if it is a token 
        // Tokens are in the form of <token>
        for (int i=0;i<words.length;i++){
            
            String word = words[i];
            
            // In cases of tokens in the middle of the sentence
            if (word.charAt(0)=='<' && word.charAt(word.length()-1)=='>'){
                tokens.add(word.substring(1, word.length()-1));
                tokenIndex.add(i);
            
            // In cases of tokens at the end of the sentence
            }else if (word.charAt(0)=='<' && word.charAt(word.length()-2)=='>'){
                tokens.add(word.substring(1, word.length()-2));
                tokenIndex.add(i);
            }
        }
        
        // Declare results
        OWLClass classX;
        OWLClass classY;
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(0).toLowerCase().equals("thing")){
            classX = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classX = factory.getOWLClass(tokens.get(0),prefixManager);
        }
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(1).toLowerCase().equals("thing")){
            classY = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classY = factory.getOWLClass(tokens.get(1),prefixManager);
        }
        
        OWLObjectProperty participate = factory.getOWLObjectProperty("Participate-In", prefixManager);
        Type2ResultSet results = getValidResultSet(classX,participate,classY);
       
        
        // Put the sentence together from the template and the generated words
        if (!results.isNull()){
            sentence = LinguisticHandler.generateType2Sentence(words, tokenIndex, results);
        }
        else{
            sentence = "This question requires participate relation in the ontology";
        }
        
        return sentence;
        
    }
    
    /**
     * Find a valid set of OWLClass X and OWLClass Y where is X is related to Y via participate-in
     * @param x
     * @param r
     * @param y
     * @return 
     */
    private Type2ResultSet getValidResultSet(OWLClass x, OWLObjectPropertyExpression r, OWLClass y) {
        
        // Declare arrayLists to store all the possible domains, ranges and object properties from the ontology for the given template
        ArrayList <OWLClass> resultX = new ArrayList<OWLClass>();
        ArrayList <OWLClass> resultY = new ArrayList<OWLClass>();
        
        // For each domain of participate-in relation
        for (Node<OWLClass> domain : reasoner.getObjectPropertyDomains(r, false)){
            
            // For each subclass of that
            for (Node<OWLClass> subclass: reasoner.getSubClasses( domain.getRepresentativeElement() , false)){
                
                // For each domain that is a subclass of token in the template and it is OWL:Nothing
                if ((reasoner.getSubClasses(x, false).containsEntity(subclass.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subclass))){
                    
                    // Store domain
                    resultX.add(subclass.getRepresentativeElement());
                }
            }
            // If domain is a class and it does not have a subclass
            if ((domain.getRepresentativeElement().isClassExpressionLiteral()) && (reasoner.getSubClasses(x, false).containsEntity(domain.getRepresentativeElement()))){
                resultX.add(domain.getRepresentativeElement());
            }
        }
        
        // For each range of the participate-in realtoin
        for (Node<OWLClass> range: reasoner.getObjectPropertyRanges(r, false)) {
            
            // For each subclass of that
            for (Node<OWLClass> subclass: reasoner.getSubClasses( range.getRepresentativeElement() , false)){
                
                // If range is a subclass of the token in the template and is not OWL:nothing
                if ((reasoner.getSubClasses(y, false).containsEntity(subclass.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subclass))){
                    
                    //Stroe range
                    resultY.add(subclass.getRepresentativeElement());
                }
            }
            
            // If domain is a class and it does not have a subclass
            if ((range.getRepresentativeElement().isClassExpressionLiteral()) && (reasoner.getSubClasses(y, false).containsEntity(range.getRepresentativeElement()))){
                resultY.add(range.getRepresentativeElement());
            }
        }
        
        // In case either there is no X or there is no Y 
        if (resultX.isEmpty()||resultY.isEmpty()){
            return new Type2ResultSet();
        // Return a randomly selected X, Y pair
        }else{
            return new Type2ResultSet(randomSelect(resultX), randomSelect(resultY));
        }
        
    }
    
    /**
     * Randomly select from an Array list of OWLClass
     * @param List
     * @return 
     */
    private OWLClass randomSelect(ArrayList<OWLClass> List){
        Random rand = new Random();
        return List.get(rand.nextInt(List.size()));
    }
    
}
