package Main;

// Imports
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

/**
 *
 * @author stevewang
 */
public class Type6Question {
    
    //Global variables 
    private static OWLOntologyManager manager;
    private static OWLOntology ontology;
    private static OWLDataFactory factory;
    private static OWLReasoner reasoner;
    private static OWLOntologyFormat format; 
    private static PrefixOWLOntologyFormat prefixFormat;
    private static PrefixManager prefixManager;
    private String sentence;
    
    
    /**
     * Constructor for Type 6 questions 
     * @param manager
     * @param ontology
     * @param factory
     * @param reasoner
     * @param format
     * @param prefixFormat
     * @param prefixManager 
     */
    public Type6Question(OWLOntologyManager manager, OWLOntology ontology,OWLDataFactory factory,OWLReasoner reasoner,OWLOntologyFormat format, PrefixOWLOntologyFormat prefixFormat,PrefixManager prefixManager){
        this.manager = manager;
        this.ontology = ontology;
        this.factory = factory;
        this.reasoner = reasoner;
        this.format = format;
        this.prefixFormat = prefixFormat;
        this.prefixManager = prefixManager;
        sentence = "";
    }
    
    /**
     * Generate questions from a template of a question type 6
     * @param template
     * @return 
     */
    public String GenerateQuestion(String template){
        // Declare an array that stores each the words of the template
        String output = "";
        
        // Declare an arrayList to store the 3 tokens in the template
        String [] words = template.split(" ");
        
        // Declare an arrayList to store the tokens in the template
        ArrayList <String> tokens = new ArrayList<String> ();
        
        // For each word in the template, check if it is a token 
        // Tokens are in the form of <token>
        for (String word : words){
            
            // In cases of tokens in the middle of the sentence
            if (word.charAt(0)=='<' && word.charAt(word.length()-1)=='>'){
                tokens.add(word.substring(1, word.length()-1));
            
            // In cases of tokens at the end of the sentence
            }else if (word.charAt(0)=='<' && word.charAt(word.length()-2)=='>'){
                tokens.add(word.substring(1, word.length()-2));
                
            }
        }
        // Output ArrayList of tokens in the form of [OWLClass X, ObjectProperty or e.g. ObjectProperty:Verb, Quantifier, OWLClass Y]
        
        // Declare results
        OWLClass classX;
        OWLClass classY;
        OWLObjectPropertyExpression objectProperty;
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(0).toLowerCase().equals("thing")){
            classX = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classX = factory.getOWLClass(tokens.get(0),prefixManager);
        }
        
        // For cases where the token is <Thing> which is the topClassNode of the ontology
        if (tokens.get(3).toLowerCase().equals("thing")){
            classY = reasoner.getTopClassNode().getRepresentativeElement();
        // For cases where the token is any other node in the ontology
        }else{
            classY = factory.getOWLClass(tokens.get(3),prefixManager);
        }
        
        String [] opSplit = tokens.get(1).split(":");
        if (opSplit.length==1) {
            objectProperty = reasoner.getTopObjectPropertyNode().getRepresentativeElement();
        } else {
            objectProperty = factory.getOWLObjectProperty(opSplit[1], prefixManager);
        }
        
        // Put the sentence together from the template and the generated words
        Type3ResultSet result = getValidResultSet(classX, objectProperty, classY);
        if (result.isNull()){
            output = "result is null, x is : "+result.getX()+" Y is : "+result.getY() + " Object Proprty is : "+result.getOP()+ " Quantifier is : "+ result.getQuantifier();
        }else{
            output = LinguisticHandler.generateType3Sentence (result, template);
        }
        return output; 
        
    }

     /**
     * Find a valid set of OWlClass X, OWLClass Y, OWLObjectProperty objectProperty, String quantifier
     * @param classX
     * @param objectProperty
     * @param classY
     * @return 
     */
    private Type3ResultSet getValidResultSet(OWLClass classX, OWLObjectPropertyExpression objectProperty, OWLClass classY) {
        
        // Declare arrayList to store all the possible result set
        ArrayList<OWLClassExpression> xSet = new ArrayList<OWLClassExpression>();
        ArrayList<OWLClassExpression> ySet = new ArrayList<OWLClassExpression>();
        ArrayList<OWLObjectPropertyExpression> opSet = new ArrayList<OWLObjectPropertyExpression>();
        ArrayList<String> qSet = new ArrayList<String>();
        
        // Get all subObjectProperties (sub-Relations) of the given object property
        ArrayList<OWLObjectPropertyExpression> subObjectProperties = getSubObjectPropertiesOf(objectProperty);
        
        // If there is subObjectProperty 
        if (!subObjectProperties.isEmpty()) {
            
            // For every subObjectProperty 
            for (OWLObjectPropertyExpression owlope : subObjectProperties ) {
                
                // Get all valid ranges of subObjectProperty 
                ArrayList<OWLClass> validRanges = validRange(classY, owlope);
                
                // For each of the valid ranges found
                for (OWLClass range: validRanges) {
                    
                    // Get all domain that have some object relation(owlope)  to classY(Range)
                    ArrayList<OWLClass> validSomeDomains = validSomeDomain(classX, owlope, range);
                    
                    // For each domain that satisfies the "some" object relation
                    for (OWLClass domain: validSomeDomains){
                        
                        // Store the results
                        Type3ResultSet result = new Type3ResultSet(domain, range, owlope, "some");
                        xSet.add(result.getX());
                        ySet.add(result.getY());
                        opSet.add(result.getOP());
                        qSet.add(result.getQuantifier());
                    }
                    
                    // Get all domain that have all object relation (owlope) to classY (Ranges)
                    ArrayList<OWLClass> validAllDomains = validAllDomain(classX, owlope, range);
                    
                    // For each domain that satisfies the "all" object relation
                    for (OWLClass domain: validAllDomains){
                        
                        // Store the results
                        Type3ResultSet result = new Type3ResultSet(domain, range, owlope, "all");
                        xSet.add(result.getX());
                        ySet.add(result.getY());
                        opSet.add(result.getOP());
                        qSet.add(result.getQuantifier());
                    }
                }
            }
            
        // If there is no such subObjectProperty, the use the given object property
        } else {
            
            // Get all valid ranges of ObjectProperty 
            ArrayList<OWLClass> validRanges = validRange(classY, objectProperty);
            
            // For each of the valid ranges found
            for(OWLClass range: validRanges){
                
                // Get all domain that have some object relation(owlope)  to classY(Range)
                ArrayList<OWLClass> validSomeDomains = validSomeDomain(classX, objectProperty, range);
                
                // For each domain that satisfies the "some" object relation
                for (OWLClass domain: validSomeDomains){
                    
                    // Store the results
                    Type3ResultSet result = new Type3ResultSet(domain, range, objectProperty, "some");
                    xSet.add(result.getX());
                    ySet.add(result.getY());
                    opSet.add(result.getOP());
                    qSet.add(result.getQuantifier());
                }
                
                // For each domain that satisfies the "all" object relation
                ArrayList<OWLClass> validAllDomains = validAllDomain(classX, objectProperty, range);
                
                // For each domain that satisfies the "all" object relation
                for (OWLClass domain: validAllDomains){
                    
                    // Store the results
                    Type3ResultSet result = new Type3ResultSet(domain, range, objectProperty, "all");
                    xSet.add(result.getX());
                    ySet.add(result.getY());
                    opSet.add(result.getOP());
                    qSet.add(result.getQuantifier());
                }
            }
        }
        
        // If there is a result set then return a randomly select result set
        if (xSet.size()==0){
            return new Type3ResultSet();
        }else{
            int index = randomIndex(xSet.size());
            return new Type3ResultSet(xSet.get(index), ySet.get(index), opSet.get(index), qSet.get(index));
        }
    }
    
    /**
     *  Get a set of valid range
     *  A range is valid if it is a range of the object property and is a subclass of the given class
     * @param classY
     * @param owlope
     * @return 
     */
    private ArrayList<OWLClass> validRange(OWLClass classY, OWLObjectPropertyExpression owlope) {
        // Declare an empty arraylist to store valid range
        ArrayList<OWLClass> validRange = new ArrayList<OWLClass> ();
        
        // Get all range of the given object property 
        NodeSet<OWLClass> allRange = reasoner.getObjectPropertyRanges(owlope, false);
        
        // For each range found
        for (Node<OWLClass> range : allRange){
            
            // For each class of range
            for (Node<OWLClass> subrange: reasoner.getSubClasses(range.getRepresentativeElement(), false)){
                
                // If it is a subclass of OWLClass Y given and that it is not an OWL:Nothing class
                if ((reasoner.getSubClasses(classY, false).containsEntity(subrange.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subrange))){
                    
                    // Add result to the arraylist
                    validRange.add(subrange.getRepresentativeElement());
                }
            }
        }
        
        return validRange;
    }
    
     /**
     * Find a valid domains that have SOME object relation to the given OWLClass range.
     * A domain is valid if it is a subclass of the given classX and that it is not an OWL:Nothing OWLClass.
     * @param x
     * @param owlop
     * @param range
     * @return 
     */
    private ArrayList<OWLClass> validSomeDomain(OWLClass classX, OWLObjectPropertyExpression owlope, OWLClass range) {
        
        // Declare an empty arrayList to store all valid SOME domain
        ArrayList<OWLClass> validDomain = new ArrayList<OWLClass>();
        
        // Get all subclass of the given OWLClass X
        NodeSet <OWLClass> validClasses = reasoner.getSubClasses(classX, false);
        
        // Get all domain that have SOME object property to the given range
        OWLObjectSomeValuesFrom allSomeDomain = factory.getOWLObjectSomeValuesFrom(owlope, range);
        Set<OWLClass> setOfSomeDomain = allSomeDomain.getClassesInSignature();

        // For each of the domain found
        for (OWLClass domain: setOfSomeDomain) {
            
            // For each of the subclass of the domain
            for (Node<OWLClass> subdomain : reasoner.getSubClasses(domain, false)){
                
                // Get the set of all subclass of the subdomain
                NodeSet<OWLClass> subSubDomain = reasoner.getSubClasses(subdomain.getRepresentativeElement(), false);
                Set<Node<OWLClass>> x = subSubDomain.getNodes();
                
                // Remove OWL:Nothing from the subsubdomain list
                x.remove(reasoner.getBottomClassNode());
                
                // If it is a subclass of the given OWLClass X, it is not an OWL:Nothing class and it has at least one subclass
                if ((validClasses.containsEntity(subdomain.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subdomain))&&(!x.isEmpty())){
                    
                    // Add the domain
                    validDomain.add(subdomain.getRepresentativeElement());
                }
            }
        }
        
        return validDomain;
    }
    
     /**
     * Find a valid domains that have All object relation to the given OWLClass range.
     * A domain is valid if it is a subclass of the given classX and that it is not an OWL:Nothing OWLClass.
     * @param x
     * @param owlop
     * @param range
     * @return 
     */
    private ArrayList<OWLClass> validAllDomain(OWLClass classX, OWLObjectPropertyExpression owlope, OWLClass range) {
        
        // Declare an empty arrayList to store all valid All domain
        ArrayList<OWLClass> validDomain = new ArrayList<OWLClass>();
        
        // Get all subclass of the given OWLClass X
        NodeSet <OWLClass> validClasses = reasoner.getSubClasses(classX, false);
        
        // Get all domain that have All object property to the given range
        OWLObjectAllValuesFrom allAllDomain = factory.getOWLObjectAllValuesFrom(owlope, range);
        Set<OWLClass> setOfAllDomain = allAllDomain.getClassesInSignature();
        
        // For each of the domain found
        for (OWLClass domain: setOfAllDomain) {
            
            // For each of the subclass of the domain
            for (Node<OWLClass> subdomain : reasoner.getSubClasses(domain, false)){
                
                // Get the set of all subclass of the subdomain
                NodeSet<OWLClass> subSubDomain = reasoner.getSubClasses(subdomain.getRepresentativeElement(), false);
                Set<Node<OWLClass>> x = subSubDomain.getNodes();
                
                // Remove OWL:Nothing from the subsubdomain list
                x.remove(reasoner.getBottomClassNode());
                
                // If it is a subclass of the given OWLClass X, it is not an OWL:Nothing class and it has at least one subclass
                if ((validClasses.containsEntity(subdomain.getRepresentativeElement()))&&(!reasoner.getBottomClassNode().equals(subdomain))&&(!x.isEmpty())){
                    
                    // Add the domain
                    validDomain.add(subdomain.getRepresentativeElement());
                }
            }
        }
        
        return validDomain;
    
    }
    
    /**
     * Return all subObjectProperty of r
     * @param r
     * @return 
     */
    private ArrayList<OWLObjectPropertyExpression> getSubObjectPropertiesOf(OWLObjectPropertyExpression r) {
        // Declare an ArrayList to store all valid sub object properties
        ArrayList<OWLObjectPropertyExpression> results = new ArrayList<OWLObjectPropertyExpression>();
        
        // For each of the sub object property of r
        for(Node<OWLObjectPropertyExpression> ope: reasoner.getSubObjectProperties(r, false)){
            // The ope is not an OWL:Nothing object and it is not defined as an inverse of another object property
            if ((!reasoner.getBottomObjectPropertyNode().getRepresentativeElement().equals(ope.getRepresentativeElement()))&&isNotAnInverse(ope)){
                results.add(ope.getRepresentativeElement());
            }
        }
        return results;
    }

    /**
     * Check if the given object relation is not an inverse
     * @param ope
     * @return 
     */
    private boolean isNotAnInverse(Node<OWLObjectPropertyExpression> ope) {
        OWLObjectPropertyExpression op = ope.getRepresentativeElement();
        String stringRep = op.toString();
        String [] sections = stringRep.split("\\(");
        if (sections[0].equals("InverseOf")){
            return false;
        }else{
            return true;
        }
    }

    /**
     * Get an random index in the given list size
     * @param size
     * @return 
     */
    private int randomIndex(int size) {
        Random rand = new Random();
        return rand.nextInt(size);
    }

}
